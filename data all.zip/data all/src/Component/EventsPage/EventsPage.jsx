import React from 'react'
import eventImg from '../../assets/images/events-6aug.jpg'
import Layout from '../Layout/Layout'
const Events = () => {
  return (
    <Layout>
      <div id="grow-section" className="grow-section container-fluid margin-top-first-container-large">
        <div className="container-lg py-4 py-lg-5">
          <div className="row">
            <div className="col-12">
              {/* <div className='w-100 events-photo' style={{ backgroundImage: `url(${PlaceholderImage})` }}>

              </div> */}
              <img src={eventImg} alt="event img" className='img-fluid' />
            </div>
          </div>
        </div>
      </div>
    </Layout>

  )
}

export default Events;