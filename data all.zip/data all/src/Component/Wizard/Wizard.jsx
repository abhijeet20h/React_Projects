import React, { useEffect } from 'react'
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';
import Layout from '../Layout/Layout'
import SpinnerModal from "../Shared/Modal/spinnerModal"
import Faq from "../Shared/Faq/Faq";

const Wizard = () => {
    const navigate = useNavigate();

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    // redirect calculation page
    const handleCalculation = () => {
        setTimeout(myGreeting, 2000);
    }

    const myGreeting = () => {
        console.log("first")
        // navigate(AdminRoutes?.Result)
        window.$('#popup-calculating-the-saleable-area').modal('hide')
        window.$('modal-backdrop').removeClass('modal-backdrop')
    }

    return (
        <Layout>
            {/*show sppiner modal*/}
            <div className="modal fade" id="popup-calculating-the-saleable-area" tabndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="false">
                <SpinnerModal HeaderMsg="Calculating the Saleable Area." informMsg="Thank you for your patience, this should not take much time." />
            </div>
            <div id="wizard-section" className="wizard-section container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><a href="index.html"
                            className="text-black text-decoration-none fw-bold">Home</a>
                        </li>
                        <li className="breadcrumb-item active" aria-current="page"><span
                            className="text-purple fw-bold">wizard</span></li>
                    </ol>
                    <h2 className="text-left mb-2 text-purple d-none d-lg-block">Wizard</h2>

                    <div className="wizard-fix-form-header">
                        <p className="fst-italic fw-normal text-16 text-purple">Take the first step towards the life of your
                            dreams….</p>
                        <div className="d-flex flex-row justify-content-between mb-2">
                            <span className="fw-bold text-purple fw-500 text-18">Redevelopment</span>
                            <span className="fst-italic fw-normal text-16">8 questions only</span>
                        </div>

                        <div className="progress mb-4 rounded-20">
                            <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "75%" }} aria-valuenow="75"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>



                    <div className="row g-3 g-lg-5">
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2 fw-500">1. Choose the type of Property</p>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                        value="option1" defaultChecked={true} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1">
                                        Society/ Apartment
                                    </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                        value="option2" />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2">
                                        Bungalow/ Row Houses
                                    </label>
                                </div>
                            </div>

                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">2. TOD Applicability</p>
                                <p className="custom-note-text">Note: Transit Oriented Development e.g. Plot within 500 meters of
                                    metro</p>
                                <div className="d-flex flex-row flex-sm-column">
                                    <div className="form-check custom-form-check me-4 me-sm-0">
                                        <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                            value="option1" defaultChecked={true} />
                                        <label className="form-check-label fw-500" htmlFor="exampleRadios1">
                                            Metro
                                        </label>
                                    </div>
                                    <div className="form-check custom-form-check">
                                        <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                            value="option2" />
                                        <label className="form-check-label fw-500" htmlFor="exampleRadios2">
                                            Non-Metro
                                        </label>
                                    </div>
                                </div>


                            </div>


                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">3. Select Core Area</p>
                                <p className="custom-note-text">Note: Transit Oriented Development e.g. Plot within 500 meters of
                                    metro</p>

                                <div className="d-flex flex-row flex-sm-column">
                                    <div className="form-check custom-form-check me-4 me-sm-0">
                                        <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                            value="option1" defaultChecked={true} />
                                        <label className="form-check-label fw-500" htmlFor="exampleRadios1">
                                            Congested
                                        </label>
                                    </div>
                                    <div className="form-check custom-form-check">
                                        <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                            value="option2" />
                                        <label className="form-check-label fw-500" htmlFor="exampleRadios2">
                                            Non- Congested
                                        </label>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">4. Is your property within municipal limits?</p>
                                <div className="d-flex flex-row flex-sm-column">
                                    <div className="form-check custom-form-check me-4 me-sm-0">
                                        <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                            value="option1" defaultChecked={true} />
                                        <label className="form-check-label fw-500" htmlFor="exampleRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div className="form-check custom-form-check">
                                        <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                            value="option2" />
                                        <label className="form-check-label fw-500" htmlFor="exampleRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">5. Gross Plot Area</p>
                                <p className="custom-note-text">Note: Conversion Sq. Ft = Sq. Mt* 10.764</p>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="Enter digits" aria-label="Text input with dropdown button" />
                                    <select className="form-select fw-400" aria-label="Default select example">
                                        <option value="1">Sq Mtr</option>
                                        <option value="2">Sq Feet</option>
                                    </select>
                                </div>
                            </div>


                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">6. Estimate area in road widening</p>
                                <p className="custom-note-text">Note: Conversion Sq. Ft = Sq. Mt* 10.764</p>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="Enter digits" aria-label="Text input with dropdown button" />
                                    <select className="form-select fw-400" aria-label="Default select example">
                                        <option value="1">Sq Mtr</option>
                                        <option value="2">Sq Feet</option>
                                    </select>
                                </div>
                            </div>


                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">7. Select Width of the Road</p>
                                <div className="input-group mb-3">
                                    <select className="form-select fw-400" aria-label="Default select example">
                                        <option defaultValue>Select Access Road</option>
                                        <option value="1">&#60; 9 mt</option>
                                        <option value="2">9 to 12 mt</option>
                                        <option value="3">12 to 15 mt</option>
                                        <option value="4">15 to 18 mt</option>
                                        <option value="5">18 to 24 mt</option>
                                        <option value="6">24 to 30 mt</option>
                                        <option value="6">&#62; 30 mt</option>
                                    </select>
                                </div>
                            </div>


                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500">8. Loading</p>
                                <p className="custom-note-text">Note: Loading over carpet area to arrive at Saleable Area in your
                                    location</p>
                                <div className="input-group mb-3 flex-column">
                                    <label htmlFor="customRange1"
                                        className="form-label fw-500 text-decoration-underline align-self-end">10%</label>
                                    <div className="d-flex justify-content-center flex-column">
                                        <input type="range" className="form-range custom-range" id="customRange1" />
                                        <div className="d-flex flex-row justify-content-between">
                                            <span className="fw-normal text-16">0%</span>
                                            <span className="fw-normal text-16">100%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12">
                            <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                <div className="form-check custom-form-check mb-3">
                                    <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                    <label className="form-check-label" htmlFor="flexCheckDefault">
                                        I agree to Terms & Conditions
                                    </label>
                                </div>
                                <button type="button" id="show-modal-button-1" className="btn btn-purple-custom px-5 text-white" data-bs-toggle="modal" data-bs-target="#popup-calculating-the-saleable-area" onClick={() => handleCalculation()}>Calculate</button>
                            </div>
                        </div>
                        <div className="col-12 mt-2">
                            <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                <p className="rounded-3 p-3 text-black custom-wizard-warning-box">UDCPR rules interpretations may vary till
                                    implementation under various planning authority. Hence this calculator is htmlFor
                                    demonstration purpose only.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Faq />
        </Layout>
    )
}

export default Wizard