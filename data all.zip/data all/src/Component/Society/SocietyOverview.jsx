import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Layout from '../Layout/Layout';
import AdminRoutes from '../../App/Route/RouteDetails';
import baseApi from '../../environment/Config';

const SocietyOverview = () => {
    const navigate = useNavigate();
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));

    const [getAllinfo, setGetAllInfo] = useState('');
    const [buildingInfo, setBuildingInfo] = useState('');

    useEffect(() => {
        window.scrollTo(0, 0)
        getAllSocietyInfo()
    }, [])

    const getAllSocietyInfo = async () => {
        try {
            var data = JSON.stringify({
                "_id": userInfo._id
            });

            var config = {
                method: 'post',
                url: `${baseApi.baseUrl}user/getinfobyid`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };
            await axios(config)
                .then(function (response) {
                    setGetAllInfo(response.data?.data[0])
                    setBuildingInfo(response.data?.data[0].building_info)
                })
        } catch (err) {
            console.log(err)
        }
    }

    const handlePubilsh = () => {
        navigate(AdminRoutes.SocietydashBoard)
    }


    return (
        <Layout>
            {getAllinfo ?
                <div id="society-overview-page-section"
                    className="society-overview-page-section container-fluid margin-top-first-container-large">
                    <div className="container-lg py-4 py-lg-5">

                        <div className="row">
                            <div className="col-12 mb-3">
                                <div className="d-flex justify-content-between flex-row mb-2">
                                    <div
                                        className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                        <div className="building-icon mr-3">
                                            <i className="fa fa-building" aria-hidden="true"></i>
                                        </div>
                                        <div className="building-text d-flex flex-column">
                                            <p className="mb-0 fw-600 text-16">Society Overview</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="progress mb-4 rounded-20">
                                    <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "90%" }} aria-valuenow="75"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>

                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-user-circle-o" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 fw-600 text-16">{getAllinfo?.society_name}</p>
                                        <p className="mb-0 fw-400 text-14">{getAllinfo?.address?.Area} {getAllinfo?.address?.State} {getAllinfo?.address?.PinNo}</p>
                                    </div>
                                </div>
                                <p className="mb-0 mt-4 fst-italic fw-600 text-16">Your society looks like this....</p>
                            </div>
                        </div>

                        <div className="row mb-5 gy-3 gy-lg-auto">
                            <div className="col-12 col-sm-6 col-md-4">
                                <div className="counter-card-2 p-3 bg-light border rounded-3">
                                    <h3>{getAllinfo?.no_of_buildings}</h3>
                                    <p>No. of buildings</p>
                                </div>

                            </div>
                            <div className="col-12 col-sm-6 col-md-4">
                                <div className="counter-card-2 p-3 bg-light border rounded-3">
                                    <h3>{getAllinfo?.no_of_flats * getAllinfo?.no_of_floors}</h3>
                                    <p>Total No. of units</p>
                                </div>
                            </div>
                        </div>

                        {getAllinfo?.society_photos[1]?.length && getAllinfo?.society_photos[2]?.length && getAllinfo?.society_photos[3]?.length && getAllinfo?.society_photos[4]?.length ?
                            <div className="d-flex flex-row justify-content-between mb-3">
                                <span className="fw-600">Photo gallery</span>
                                <span>See all</span>
                            </div>
                            : null
                        }

                        <div className="row mb-5 gy-3 gy-lg-auto">
                            {getAllinfo?.society_photos[1]?.length ?
                                < div className="col-12 col-lg-3">
                                    <div className="counter-card-2">
                                        <img src={getAllinfo?.society_photos[1]} className="img-fluid rounded-3" alt="image" />
                                    </div>

                                </div>
                                : null
                            }

                            {getAllinfo?.society_photos[2]?.length ?
                                <div className="col-12 col-lg-3">
                                    <div className="counter-card-2">
                                        <img src={getAllinfo?.society_photos[2]} className="img-fluid rounded-3" alt="image" />
                                    </div>
                                </div>
                                : null
                            }

                            {getAllinfo?.society_photos[3]?.length ?
                                <div className="col-12 col-lg-3">
                                    <div className="counter-card-2">
                                        <img src={getAllinfo?.society_photos?.length ? getAllinfo?.society_photos[3] : null} className="img-fluid rounded-3" alt="image" />
                                    </div>
                                </div>
                                : null
                            }
                            {getAllinfo?.society_photos[4]?.length ?
                                <div className="col-12 col-lg-3">
                                    <div className="counter-card-2">
                                        <img src={getAllinfo?.society_photos?.length ? getAllinfo?.society_photos[4] : null} className="img-fluid rounded-3" alt="image" />
                                    </div>
                                </div>
                                : null
                            }
                        </div>

                        {/*
                <p className="fw-600">Wings/Buildings</p>
                    <div className="row mb-5 gy-3 gy-lg-auto">
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A1
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A2
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A3
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A4
                            </div>
                        </div>
                    </div>
                */}


                        <div className="d-flex flex-row justify-content-between mb-3">
                            <span className="fw-600">Floors & Flats</span>
                            <span className="text">View Building Configuration</span>
                        </div>

                        <div className="row mt-5 gy-3 gy-lg-auto">
                            <div className="col-12 text-center">
                                <button className="btn btn-purple-custom px-5" onClick={(e) => handlePubilsh(e)}>Publish</button>
                                <a href="#" className="d-block text-14"><i className="fa fa-link me-1 text-orange mt-3" aria-hidden="true"></i>Share
                                    invite to Unit owner</a>
                            </div>
                        </div>

                    </div>
                </div>
                : null
            }
        </Layout >
    )
}

export default SocietyOverview