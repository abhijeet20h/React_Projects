import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import Layout from '../../Layout/Layout';
import AdminRoutes from '../../../App/Route/RouteDetails';
import axios from 'axios';
import baseApi from '../../../environment/Config';

const FloorDetails = () => {
    const naviget = useNavigate();
    const { floors } = useParams();
    const { units } = useParams()
    const location = useLocation();
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));

    const [getAllinfo, setGetAllInfo] = useState('');
    const [buildingInfo, setBuildingInfo] = useState('');
    // const { buldingInfo } = useLocation()

    // console.log(location.state.buldingInfo);


    useEffect(() => {
        window.scrollTo(0, 0)
        getAllSocietyInfo()
    }, [])

    const getAllSocietyInfo = async () => {
        try {
            var data = JSON.stringify({
                "_id": userInfo._id
            });

            var config = {
                method: 'post',
                url: `${baseApi.baseUrl}user/getinfobyid`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };
            await axios(config)
                .then(function (response) {
                    setGetAllInfo(response.data?.data[0])
                    console.log(response.data?.data[0].building_info[floors]?.building_details)
                    setBuildingInfo(response.data?.data[0].building_info[floors]?.building_details)
                })
        } catch (err) {
            console.log(err)
        }
    }

    return (
        <Layout>
            <div id="building-details-page-section" className="blogs-details-section welcome-page-section building-details-page-section container-fluid margin-top-first-container-small">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-between flex-row mb-2">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 fw-600 text-16">Floor Details</p>
                                    </div>
                                </div>
                                <span className="fst-italic fw-normal text-16 text-decoration-underline cursor-pointer" onClick={() => naviget(AdminRoutes.WingsDetails)} >Back to Society Configuration </span>
                            </div>
                            <div className="progress mb-4 rounded-20">
                                <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "75%" }} aria-valuenow="75"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <div className="d-flex flex-row justify-content-between justify-content-sm-start align-items-center">
                                <div>
                                    <p className="fw-600 text-purple me-0 me-sm-3">Configure Building: </p>
                                </div>
                                <div>
                                    <div className="input-group mb-3">
                                        <select className="form-select fw-400 pe-5" aria-label="Default select example">
                                            <option value="1">A1</option>
                                            <option value="2">A2</option>
                                            <option value="3">B1</option>
                                            <option value="4">B2</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-between flex-row">

                                <div className="text-purple fw-600 welcome-page-details-heading">
                                    <span className="me-2 fw-bold fs-4 text-purple">{buildingInfo?.length}</span><span className='fw-bold fs-4 text-purple"'>Floors</span>
                                </div>

                                {/* <button className="btn btn-gray-custom py-1 px-3" > Add Floors +</button>*/}

                            </div>
                        </div>
                    </div>

                    <div className="row g-3">
                        {buildingInfo?.length && buildingInfo?.map((value, i) => {
                            return (
                                <div key={i} className="col-12">
                                    <div className="building-cards-container w-100 h-100 rounded-15 p-3">
                                        <div className="d-flex flex-row justify-content-between">
                                            <div>
                                                <h4 className="fw-600 text-purple">Floor {i + 1}</h4>
                                            </div>
                                            <div>
                                                <label className="switch custom-toggle-switch-with-text">
                                                    <input type="checkbox" id="togBtn" />
                                                    <div className="slider round"></div>
                                                </label>
                                            </div>
                                        </div>

                                        <div className="row g-3 row-cols-2 row-cols-md-4">
                                            {value.floor_no.map((val, index) => {
                                                return (< div className="col-6 col-sm-6 " key={index}>
                                                    <div className="custom-buiding-details-card bg-light p-3">
                                                        <div className="row mb-3">
                                                            <div className="col-12 cursor-pointer" onClick={() => naviget('/unit_details/' + index + '/' + i + '/' + floors)}>
                                                                <div
                                                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                                                    <div className="building-icon mr-3">
                                                                        <i className="fa fa-building" aria-hidden="true"></i>
                                                                    </div>
                                                                    <div className="building-text d-flex flex-column">
                                                                        <p className="mb-0">Unit</p>
                                                                        <p className="mb-0">Details</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="row">
                                                            <div className="col-12 mb-2">
                                                                <div className="input-group mb-3">
                                                                    <input type="text" className="form-control" placeholder="A-101" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                                                                    <span className="input-group-text bg-light" id="basic-addon2"><i className="fa fa-pencil-square-o" aria-hidden="true"></i></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>)
                                            })}
                                        </div>


                                        {/*
                                 <div className="d-flex flex-row justify-content-end ">

                                        <button className="btn btn-gray-custom py-1 px-3 mt-3" > Add Building +</button>
                                    </div>
                                */}
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                    {/*
                 <div className="row mt-5">
                        <div className="col-12 text-center">
                            <button className="btn btn-purple-custom px-5">Save</button>
                        </div>
                    </div>
                */}
                </div>
            </div>
        </Layout >
    )
}

export default FloorDetails