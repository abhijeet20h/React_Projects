import React, { useEffect, useState } from 'react';
import Layout from "../Layout/Layout";
import MapGoogle from '../Shared/GoogleMap/MapGoogle';
import axios from 'axios';
import baseApi from '../../environment/Config';
import { toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';

const SocietyDetails = () => {
    const navigate = useNavigate();
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));
    const initialDevStep1Values = { SocietyName: "", Location: "", Gross_plot_area: "" };
    const [formDeveStepValue, setFormDeveStepValue] = useState(initialDevStep1Values);
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setisSubmit] = useState(false);

    const handleChangeDevStep = (e) => {
        const { name, value } = e.target;
        setFormDeveStepValue({ ...formDeveStepValue, [name]: value });
    };


    const [location, setGetDetails] = useState({});
    const [latitude, setLatitude] = useState('');
    const [longitude, setLongitude] = useState('');

    useEffect(() => {
        navigator.geolocation.getCurrentPosition(function (position) {
            setLatitude(position.coords.latitude);
            setLongitude(position.coords.longitude);
        });
    }, [])

    const initialAddressValues = { PinNo: "", State: "", Area: "" };
    const [AddressValue, setAddressValue] = useState(initialAddressValues);

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])





    const handleChangeAddress = (e) => {
        const { name, value } = e.target;
        setAddressValue({ ...AddressValue, [name]: value });
    };

    const validate = (valuesDevstep, valueAddress, Location) => {
        const errors = {};
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;//for email
        // const regexalphabet = /^[a-zA-Z ]*$/i; //for alphabets
        
        if (!valuesDevstep?.SocietyName) {
            errors.SocietyName = "Field should not be blank";
        }
        if (!Location) {
            errors.Location = "Field should not be blank";
        }
        if (!valuesDevstep?.Gross_plot_area) {
            errors.Gross_plot_area = "Field should not be blank";
        }
        if (!valueAddress?.PinNo) {
            errors.PinNo = "Field should not be blank";
        }
        if (!valueAddress?.State) {
            errors.State = "Field should not be blank";
        }
        if (!valueAddress?.Area) {
            errors.Area = "Field should not be blank";
        }

        return errors;
    };


    const handleSubmit = (e) => {
        e.preventDefault();
        setFormErrors(validate(formDeveStepValue, AddressValue, location));
        setisSubmit(true);
    }

    useEffect(() => {
        console.log(userInfo)
        if (Object.keys(formErrors).length === 0 && isSubmit) {
            try {
                var data = JSON.stringify({
                    "society_name": formDeveStepValue?.SocietyName,
                    "location": location,
                    "address": AddressValue,
                    "choose_property": "Residential",
                    "propery_type": "Society/ Apartment",
                    "gross_plot_area": formDeveStepValue?.Gross_plot_area,
                    "name": userInfo.full_name,
                    "appointment_letter": userInfo.appointment_letter,
                    "property_type": "Apartment",
                    "society_photos": [],
                    "no_of_buildings": 0,
                    "no_of_floors": 0,
                    "no_of_flats": 0,
                    "garage": 0,
                    "outhouse": 0,
                    "shopes": 0,
                    "offices": 0,
                    "building_info": {},
                    "email": userInfo.email,
                    "mobile": userInfo.mobile,
                    "company_name": "",
                    "entity_name": "",
                    "Website": "",
                    "service_year": 0,
                    "redevelopment_year": 0,
                    "expertise": "",
                    "company_logo": "",
                    "Payment_Link_Id": "",
                    "balance_sheet": "",
                    "income_tax_return": "",
                    "cibil_score": "",
                    "partners_info": [],
                    "roles": 1
                });

                var config = {
                    method: 'put',
                    url: `${baseApi.baseUrl}user/updateuser/${userInfo._id}`,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: data
                };

                axios(config)
                    .then(function (response) {
                        toast("Profile Update Successfully");
                        localStorage.setItem("drvalid", JSON.stringify(response.data))
                        navigate(AdminRoutes.SocietyPhotos);
                    })
            } catch (err) {
                console.log(err)
            }
        }
    }, [formErrors])
 

    return (
        <Layout>
            <div id="society-details-section" className="container-fluid margin-top-first-container-small form-section society-details-section">
                <div className="container-lg py-4 py-lg-5">

                    <div>
                        <div className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                            <div className="building-icon mr-3"> <i className="fa fa-building" aria-hidden="true"></i> </div>
                            <div className="building-text d-flex flex-column">
                                <p className="mb-0 fw-600">Society Details</p> 
                            </div>
                        </div>
                        <div className="progress mb-4 rounded-20">
                            <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "25%" }} aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>


                    <div className="row gy-3 gy-lg-5">
                        {/*
                     <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className='text-danger'>* </span>Society</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control" placeholder="Vishal Heights" aria-label="Recipient's username" aria-describedby="basic-addon2" name='SocietyName' onChange={(e) => handleChangeDevStep(e)} /> <span className="input-group-text bg-light" id="basic-addon2"><i className="fa fa-pencil-square-o" aria-hidden="true"></i></span>

                                </div>
                                <p className='text-danger'>{formErrors?.SocietyName}</p>
                            </div>
                        </div>
                    */}

                        <div className="col-12 col-sm-12 col-md-12 col-lg-6">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className='text-danger'>* </span>Society</label>
                                <div className="input-group mb-1">
                                    <input type="text" disabled  className="form-control input-group-first-input"  defaultValue={userInfo?.society_name} value={userInfo?.society_name} aria-label="Recipient's username" aria-describedby="basic-addon2" name='SocietyName' onChange={(e) => handleChangeDevStep(e)} />
                                    <select className="form-select fw-400 flex-grow-5" aria-label="Default select example">
                                        <option value="1">Co-operative Housing Society</option>
                                        <option value="2">Apartment</option>
                                    </select>

                                </div>
                                <p className='text-danger mb-0'>{formErrors?.SocietyName}</p>
                            </div>
                        </div>

                        <div className="col-12">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"> <span className='text-danger'>* </span>Address</label>
                                <div className="row gy-2">
                                    <div className="col-12 col-md-6 col-lg-4">
                                        <input  type="text" className="form-control" id="exampleFormControlInput1" placeholder="Pin Code" name='PinNo' onChange={(e) => handleChangeAddress(e)} />
                                        <p className='text-danger mb-0'>{formErrors?.PinNo}</p>
                                    </div>

                                    <div className="col-12 col-md-6 col-lg-4">
                                        <input   type="email" className="form-control" id="exampleFormControlInput1" placeholder="State"  name='State' onChange={(e) => handleChangeAddress(e)} />
                                        <p className='text-danger mb-0'>{formErrors?.State}</p>
                                    </div>
                                    <div className="col-12 col-md-6 col-lg-4">
                                        <input onkeypress="return /[a-z]/i.test(event.key)" type="text" className="form-control" id="exampleFormControlInput1" placeholder="City, Area" name='Area' onChange={(e) => handleChangeAddress(e)} />
                                        <p className='text-danger mb-0'>{formErrors?.Area}</p>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <div className="col-12">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2 fw-500"><span className='text-danger'>* </span>Your location</p>
                                <MapGoogle setGetDetails={setGetDetails} name='Location' onChange={(e) => handleChangeDevStep(e)} />
                                <p className='text-danger mb-0'>{formErrors?.Location}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2 fw-500">Choose Property :</p>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked readOnly />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1"> Society/ Apartment </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2" checked={false} readOnly />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2"> Mhada </label>
                                </div>
                                <div className="form-check custom-form-check mb-0">
                                    <input className="form-check-input" disabled type="radio" name="exampleRadios" id="exampleRadios2" value="option2" />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2"> Bungalow/ Row Houses </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2 fw-500">Choose the type of Property:</p>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="checkbox" name="exampleRadios" id="exampleRadios1" value="option1" checked readOnly />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1"> Residential </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="checkbox" name="exampleRadios" id="exampleRadios2" value="option2" checked={false} readOnly />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2"> Commercial </label>
                                </div>
                                <div className="form-check custom-form-check mb-0">
                                    <input className="form-check-input" disabled type="checkbox" name="exampleRadios" id="exampleRadios3" value="option3" />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios3"> Industrial </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2  fw-500"><span className='text-danger'>* </span>Gross Plot Area (GPA)</p>
                                <div className="input-group mb-0">
                                    <input type="text" className="form-control input-group-first-input" placeholder="Enter digits" aria-label="Text input with dropdown button" name='Gross_plot_area' onChange={(e) => handleChangeDevStep(e)} />
                                    <select className="form-select fw-400" aria-label="Default select example">
                                        <option value="1">Sq Mtr</option>
                                        <option value="2">Sq Feet</option>
                                    </select>

                                </div>
                                <p className='text-danger mb-0'>{formErrors?.Area}</p>
                            </div>
                        </div>

                        <div className="col-12 text-center mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <button type="button" className="btn btn-purple-custom px-5" onClick={(e) => handleSubmit(e)}>Next</button>
                        </div>
                    </div>
                </div>
            </div>
        </Layout >
    )
}

export default SocietyDetails;