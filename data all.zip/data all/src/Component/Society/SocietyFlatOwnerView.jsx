import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import Layout from '../Layout/Layout';
import baseApi from '../../environment/Config';
// import AdminRoutes from '../../../App/Route/RouteDetails';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { toast } from 'react-toastify';

const SocietyFlatOwnerView = () => {
    const navigate = useNavigate()
    const [name, setName] = useState("");
    const [nameErr, setNameErr] = useState("")
    const [email, setEmail] = useState("");
    const [emailErr, setEmailErr] = useState("")
    const [mobileNo, setMobileNo] = useState("")
    const [mobileErr, setMobileErr] = useState("")
    const { floors } = useParams();
    const { unit_no } = useParams();
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    const usernameRegex = /^[a-zA-Z ]*$/;

    const userInfo = JSON.parse(localStorage.getItem('drvalid'));
    console.log(userInfo)


    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    // valid Name 
    const hadleName = (e) => {
        if (e.target.value.length === 0) {
            setNameErr("Name Should Not Be Blank");
        } else if (e.target.value.length < 2) {
            setNameErr(
                "Name Should Not Less Than 3 Latter"
            );
        } else if (!usernameRegex.test(e.target.value)) {
            setNameErr("username is invalid");
        } else if (e.target.value.length > 2) {
            setNameErr("");
            setName(e.target.value)
        }
    }



    // set valid email
    const handleEmail = (e) => {
        if (!e.target.value) {
            setEmailErr("Email is required!");
        } else if (!regex.test(e.target.value)) {
            setEmailErr("This is not a valid email format!");
        } else if (regex.test(e.target.value)) {
            setEmailErr("");
            setEmail(e.target.value)
        }
    }

    // set valid mobile
    const handleMobileNumber = (e) => {
        if (e.target.value.match(/^(\+\d{1,3}[- ]?)?\d{10}$/) && e.target.value) {
            setMobileNo(e.target.value)
            setMobileErr("")
        } else {
            setMobileNo(null)
            setMobileErr("Enter Valid Mobile Number")
        }
    }

        const handelSave = () => {
            var data = JSON.stringify({
                "created_by": userInfo._id,
                "property_type": userInfo.data?.choose_property,
                "society_name": userInfo.data?.society_name,
                "wing": "A1",
                "floor": "3",
                "flat": "101",
                "name": name, //owner name  
                "email": email,
                "mobile": parseInt(mobileNo),
                "wapp_number": "No",
                "roles": 2
            });

            
        var config = {
            method: 'post',   
            url: `${baseApi.baseUrl}user/getinfobyid`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios(config)
            .then(function (response) {
                console.log(JSON.stringify(response.data));
                    navigate('/floor_details/' + floors)
            })
            .catch(function (error) {
                console.log(error);
            });
    }


  


    return (
        <Layout>
            <div id="building-details-page-section"
                className="building-details-page-section container-fluid margin-top-first-container-small">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-center flex-row mb-3">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0">Orchid Estate</p>
                                        <p className="mb-0"> 22/A Gandhi road, city, state-223345</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row g-3 gx-lg-5 gy-lg-2">
                        <div className="col-12 mb-2">
                            <div className="d-flex justify-content-between flex-row">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-4 text-18 text-gray fw-bold">Unit No: <span className="fw-bold text-18">A1-101</span></p>
                                        <p className="mb-0 fw-bold text-16">Configure Unit</p>
                                        <p className="mb-0">Please enter unit owner details</p>
                                    </div>
                                </div>
                                <div>
                                    <label className="switch custom-toggle-switch-with-text">
                                        <input type="checkbox" id="togBtn" />
                                        <div className="slider round"></div>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Please Enter Unit owner’s name</label>
                                <div className="d-flex justify-content-between flex-row">
                                    <div>
                                        <p>Rajiv Jha</p>
                                    </div>
                                    <div>
                                        <p>Owner</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Please Enter Unit owner’s contact no.</label>
                                <p>9847892772</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Please Enter Unit owner’s Email id.</label>
                                <p>rajiv.jha@gmail.com</p>
                            </div>
                        </div>
                        {/* <div className="col-12 text-center mt-5 mt-lg-5 mb-4 mb-lg-0">
                        <CopyToClipboard text={`http://ec2-43-205-53-236.ap-south-1.compute.amazonaws.com/#/property_owner_register/${userInfo._id}/${userInfo.data?.society_name}`} ><span className="col-12 text-center cursor-pointer"><i className="fa fa-link me-1 text-orange mt-3" aria-hidden="true"></i>Share invite to Unit owner</span></CopyToClipboard>
                    </div> */}

                        <div className="col-12 text-center mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <CopyToClipboard text={`http://localhost:3000/#/property_owner_register/${userInfo._id}/${userInfo.data?.society_name}`} ><span className="col-12 text-center cursor-pointer"><i className="fa fa-link me-1 text-orange mt-3" aria-hidden="true"></i>Share invite to Unit owner</span></CopyToClipboard>
                        </div>


                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default SocietyFlatOwnerView