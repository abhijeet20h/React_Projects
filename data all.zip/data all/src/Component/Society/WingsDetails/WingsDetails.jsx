import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../../Layout/Layout';
import DefaultImage from "../../../assets/images/growmore-1.jpg";
import { useNavigate } from 'react-router-dom';
import AdminRoutes from '../../../App/Route/RouteDetails';
import baseApi from '../../../environment/Config';
import { CopyToClipboard } from 'react-copy-to-clipboard';

const WingsDetails = () => {
    const navigate = useNavigate();
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));
    console.log(userInfo.data?.society_photos[0].length)

    const [getAllinfo, setGetAllInfo] = useState('');
    const [buildingInfo, setBuildingInfo] = useState('');


    useEffect(() => {
        window.scrollTo(0, 0)
        getAllSocietyInfo()
    }, [])

    const getAllSocietyInfo = async () => {
        try {
            var data = JSON.stringify({
                "_id": userInfo._id
            });

            var config = {
                method: 'post',
                url: `${baseApi.baseUrl}user/getinfobyid`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };
            await axios(config)
                .then(function (response) {
                    setGetAllInfo(response.data?.data[0])
                    console.log(response.data?.data[0].building_info)
                    setBuildingInfo(response.data?.data[0].building_info)
                })
        } catch (err) {
            console.log(err)
        }
    }

    const handleSave = async (e) => {
        console.log("save", buildingInfo);
        console.log("getAllinfo", getAllinfo.no_of_floors);
        e.preventDefault();
        try {
            var data = JSON.stringify({
                "no_of_buildings": parseInt(getAllinfo.no_of_buildings), //number
                "no_of_floors":parseInt( getAllinfo.no_of_floors),  
                "no_of_flats": parseInt(getAllinfo.no_of_flats),  
                "garage": parseInt(getAllinfo.garage),  //number  
                "outhouse": parseInt(getAllinfo.outhouse),
                "shopes": parseInt(getAllinfo.shopes),
                "offices": parseInt(getAllinfo.offices),
                "society_name": userInfo.data?.society_name,
                "location": userInfo.data?.location,
                "address": userInfo.data?.address,
                "choose_property": "Residential",
                // "propery_type": "Society/ Apartment",
                "gross_plot_area": parseInt(userInfo.data?.gross_plot_area),
                "name": userInfo.data?.full_name,
                "appointment_letter": userInfo.data?.appointment_letter,
                "property_type": "Apartment",
                "society_photos": userInfo.data?.society_photos,
                "email": userInfo.data?.email,
                "mobile": parseInt(userInfo.data?.mobile),
                "company_name": "",
                "entity_name": "",
                "Website": "",
                "service_year": 0,
                "building_info": {}, 
                "redevelopment_year": 0,
                "expertise": "",
                "company_logo": "",
                "Payment_Link_Id": "",
                "balance_sheet": "",
                "income_tax_return": "",
                "cibil_score": "",
                "partners_info": [],
                "roles": 1
            });

            var config = {
                method: 'put',
                url: `${baseApi.baseUrl}user/updateuser/${userInfo._id}`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            await axios(config)
                .then(function (response) {
                    navigate(AdminRoutes.SocietyOverview)
                })
        } catch (err) {
            console.log(err)
        }
    }

    const goToHandleFloor = (floors) => {
        // navigate(AdminRoutes.FloorDetails);
        navigate('/floor_details/' + floors)
    }

    // handle Wing Name for all buldings

    const handleWingName = (e, i) => {
        buildingInfo[i].wing = e.target.value
        getAllinfo.building_info[i].wing = e.target.value
    }


    const handleSerise = (e, i) => {
        buildingInfo[i].flat_series = e.target.value
        getAllinfo.building_info[i].flat_series = e.target.value
    }

    return (
        <Layout>
            <div id="welcome-page-section" className="blogs-details-section welcome-page-section container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">

                    <div className="row">
                        <div className="col-12 pb-2 pt-0 pl-lg-4">
                            <h2 className="text-start text-lg-start mb-2 mb-lg-2 text-purple fw-bold text-uppercase">
                                WELCOME to {userInfo.data?.society_name}
                            </h2>
                        </div>
                    </div>


                    <div className="row mb-3">
                        <div className="col-12">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper grow-card-img1" style={{
                                    backgroundImage: `url(${userInfo.data?.society_photos[0]?.length ? userInfo.data.society_photos[0] : DefaultImage})`
                                }}
                            >
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-between flex-row">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0">{userInfo.data?.society_name}</p>
                                        <p className="mb-0">{userInfo.data?.address?.Area} {userInfo.data?.address?.State} {userInfo.data?.address?.PinNo}</p>
                                    </div>
                                </div>
                                <div>
                                    <i className="fa fa-2x fa-info-circle text-purple" aria-hidden="true"></i>
                                </div>
                            </div>


                        </div>
                    </div>

                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-between flex-row">

                                <div className="text-purple fw-600 mb-4 welcome-page-details-heading">
                                    <span className="me-2">{userInfo.data?.no_of_buildings}</span><span>buildings</span><span className="mx-2">|</span>
                                    <span className="me-2">{userInfo.data?.no_of_floors}</span><span>Floors</span><span className="mx-2">|</span>
                                    <span className="me-2">{userInfo.data?.no_of_flats}</span><span>units each floor</span><span className="mx-2"></span>
                                </div>

                                {/*<button className="btn btn-gray-custom py-1 px-3" > Add Building +</button>*/}

                            </div>
                        </div>
                    </div>

                    <div className="row g-3">
                        {getAllinfo?.building_info?.map((val, i) => {
                            return (
                                <div key={i} className="col-12 col-sm-6 col-md-6 col-lg-4">
                                    <div className="custom-buiding-details-card bg-light p-3 rounded-3">
                                        <div className="row">
                                            <div className="col-3 col-sm-12 col-md-3 text-start text-sm-center text-md-start mb-0 mb-sm-2 mb-md-0">
                                                <i className="fa fa-building" aria-hidden="true" style={{ fontSize: "5rem" }}></i>
                                            </div>
                                            <div className="col-9 col-sm-12 col-md-9">
                                                <div className="row">
                                                    <div className="col-12 mb-2">
                                                        <div className="input-group mb-3">
                                                            <input type="text" className="form-control me-2 rounded-2" placeholder="Enter wing" aria-label="Recipient's username" aria-describedby="basic-addon2" maxLength="25" onChange={(e) => handleWingName(e, i)} />
                                                            <input type="text" className="form-control rounded-2" placeholder="Enter flat" aria-label="Recipient's username" aria-describedby="basic-addon2" maxLength="10" onChange={(e) => handleSerise(e, i)} />

                                                        </div>
                                                    </div>
                                                    <div className="col-4 col-sm-6 col-md-6 col-lg-6">
                                                        <div className="row">
                                                            <div className="col-12">
                                                                <div className="row">
                                                                    <div className="col-12 text-start text-sm-center text-md-start">
                                                                        <h4 className="mb-0"><span className="text-orange fw-bold text-20">{val?.floor}</span></h4>
                                                                    </div>
                                                                    <div className="col-12 text-start text-sm-center text-md-start">
                                                                        <p className="text-gray">
                                                                            Floors
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-4 col-sm-6 col-md-6 col-lg-6">
                                                        <div className="row">
                                                            <div className="col-12">
                                                                <div className="row">
                                                                    <div className="col-12 text-start text-sm-center text-md-start">
                                                                        <h4 className="mb-0"><span className="text-green fw-bold text-20">{val?.unit_count}</span></h4>
                                                                    </div>
                                                                    <div className="col-12 text-start text-sm-center text-md-start">
                                                                        <p className="text-gray">
                                                                            Flats
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-4 offset-sm-3 col-sm-6 offset-md-0 col-md-6 col-lg-6 text-start text-sm-center text-md-start">
                                                        <button className="btn btn-purple-custom btn-sm text-08em px-0 welcome-page-configure-button" onClick={() => goToHandleFloor(i)} >Configure<i className="fa fa-chevron-right ms-2" aria-hidden="true"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>

                    {/* <div className="row mt-5">
                        <div className="col-12 text-center">
                            <button className="btn btn-purple-custom px-5" onClick={(e) => handleSave(e)}>Save</button>
                        </div>
                        <CopyToClipboard text={`http://ec2-43-205-53-236.ap-south-1.compute.amazonaws.com/#/property_owner_register/${userInfo._id}/${userInfo.data?.society_name}`} ><span className="col-12 text-center cursor-pointer"><i className="fa fa-link me-1 text-orange mt-3" aria-hidden="true"></i>Share invite to Unit owner</span></CopyToClipboard>
                    </div> */}


                    <div className="row mt-5">
                        <div className="col-12 text-center">
                            <button className="btn btn-purple-custom px-5" onClick={(e) => handleSave(e)}>Save</button>
                        </div>
                        <CopyToClipboard text={`http://localhost:3000/#/property_owner_register/${userInfo._id}/${userInfo.data?.society_name}`} ><span className="col-12 text-center cursor-pointer"><i className="fa fa-link me-1 text-orange mt-3" aria-hidden="true"></i>Share invite to Unit owner</span></CopyToClipboard>
                    </div>
                </div>

            </div>
        </Layout >
    )
}

export default WingsDetails;