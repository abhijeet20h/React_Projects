import React from 'react';
import Layout from '../Layout/Layout';
import DrLogo1 from '../../assets/images/society-dashboard-dr-logo.PNG'
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper";
import DrLogo from '../../assets/images/drfavicon.png'
import ZohoLogo from '../../assets/images/zoho.png'
import admin1 from '../../assets/images/Placeholder-image.png'
import admin2 from '../../assets/images/Placeholder-image.png'
import admin3 from '../../assets/images/Placeholder-image.png'

const OwnerDashBoard = () => {
    const navigate = useNavigate();

    return (
        <Layout>
            <div id="society-configuration-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">

                        <div className="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2">
                            <div className="d-flex justify-content-between flex-row mb-3">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0">society_name</p>
                                        <p className="mb-0"> Orchid Estate 22/A Gandhi road, city, state-223345</p>
                                    </div>
                                </div>
                                <div>
                                    <i onClick={() => navigate(AdminRoutes?.FlatOwnerProfile)} className="fa fa-2x fa-user-circle-o text-purple cursor-pointer" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div className="card custom-form-card p-3">
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control" placeholder="Search for services" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                                    <span className="input-group-text bg-light" id="basic-addon2"><i className="fa fa-search" aria-hidden="true"></i></span>
                                </div>
                                <p className="text-center text-orange fw-600 text-16">What can we help you with?</p>
                                <div className="col-12 text-center">
                  <div className="row gy-5">
                    <div className="col-12 col-lg-4 d-flex flex-row justify-content-center align-items-center">
                      <div className='box-shadow-style1 rounded-3 p-3 h-100 w-75 d-flex flex-row justify-content-center align-items-center' style={{ minHeight: "150px", maxWidth: "150px" }} >
                        <img src={DrLogo} alt="" width="120px" height="auto" srcSet="" />
                      </div>

                    </div>
                    <div className="col-12 col-lg-4">
                    <a target="_blank" href="https://zoho.com" className='w-100 h-100  d-flex flex-row justify-content-center align-items-center'>
                      <div className='box-shadow-style1 rounded-3 p-3 h-100 w-75 d-flex flex-row justify-content-center align-items-center' style={{ minHeight: "150px", maxWidth: "150px" }} >
                        <img src={ZohoLogo} alt="" width="140px" height="auto" srcSet="" />                        
                      </div>
                      </a>
                    </div>
                    <div className="col-12 col-lg-4">
                    <a target="_blank" href="https://google.com" className='w-100 h-100  d-flex flex-row justify-content-center align-items-center'>
                      <div className='box-shadow-style1 rounded-3 p-3 h-100 w-75 d-flex flex-row justify-content-center align-items-center' style={{ minHeight: "150px", maxWidth: "150px" }} >
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 40.502 37.462">
                          <g id="Group_8768" data-name="Group 8768" transform="translate(15971.75 -1977)">
                            <path id="Icon_awesome-hand-holding" data-name="Icon awesome-hand-holding" d="M39.748,23.07a2.327,2.327,0,0,0-3,0l-6.5,5.2a4.476,4.476,0,0,1-2.812.984H19.125a1.125,1.125,0,0,1,0-2.25H24.63a2.341,2.341,0,0,0,2.341-1.87A2.253,2.253,0,0,0,24.75,22.5H13.5a8.275,8.275,0,0,0-5.21,1.849L5.02,27h-3.9A1.128,1.128,0,0,0,0,28.125v6.75A1.128,1.128,0,0,0,1.125,36H26.212a4.505,4.505,0,0,0,2.813-.984l10.631-8.508A2.249,2.249,0,0,0,39.748,23.07Z" transform="translate(-15971.75 1978.462)" fill="#381f54" />
                            <g id="noun-rupee-1060244" transform="translate(-16098.95 1909.801)">
                              <path id="Path_5940" data-name="Path 5940" d="M147.53,67.2a10.3,10.3,0,1,0,7.312,3.017A10.348,10.348,0,0,0,147.53,67.2Zm6.143,16.473a8.683,8.683,0,0,1-6.143,2.555,8.57,8.57,0,0,1-6.143-2.555,8.683,8.683,0,0,1-2.555-6.143,8.57,8.57,0,0,1,2.555-6.143,8.683,8.683,0,0,1,6.143-2.555,8.57,8.57,0,0,1,6.143,2.555,8.683,8.683,0,0,1,2.555,6.143A8.57,8.57,0,0,1,153.673,83.672Z" fill="#381f54" />
                              <path id="Path_5941" data-name="Path 5941" d="M275.64,197.247h2.392a.948.948,0,0,1,.816.462H275.64v1.278h3.207a.956.956,0,0,1-.816.462H274.96l4.648,4.947.87-.924-2.61-2.773h.217a2.286,2.286,0,0,0,2.12-1.713h1.386v-1.251h-1.386c-.054-.163-.109-.326-.163-.462h1.55V196H275.64Z" transform="translate(-131.073 -122.546)" fill="#381f54" />
                            </g>
                          </g>
                        </svg>                        
                      </div>
                      </a>
                    </div>
                  </div>
                  <p className='mt-4 fw-600 text-16'>Redevelopment</p>

                </div>

                {/* <div className="swipper-container-custom SocietyDashboardSwiperContainer">
                  <Swiper
                    spaceBetween={10}
                    slidesPerView={3}
                    navigation={{
                      nextEl: ".swiper-button-next",
                      prevEl: ".swiper-button-prev",
                    }}
                    breakpoints={{

                      300: {
                        slidesPerView: 2,
                        slidesPerGroup: 1,
                        spaceBetweenSlides: 50,
                      },
                      860: {
                        slidesPerView: 2,
                        slidesPerGroup: 1,
                        spaceBetweenSlides: 50,
                      },
                      990: {
                        slidesPerView: 3,
                        slidesPerGroup: 1,
                        spaceBetweenSlides: 40,
                      },
                    }}
                    className="swiper societyDashboardSwiper"
                  >
                    <div className="swiper societyDashboardSwiper">
                      <div className="swiper-wrapper">
                        <SwiperSlide>
                          <div className="swiper-slide">
                            <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                          </div>
                        </SwiperSlide>
                        <SwiperSlide>
                          <div className="swiper-slide">
                            <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                          </div>
                        </SwiperSlide>
                        <SwiperSlide>
                          <div className="swiper-slide">
                            <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                          </div>
                        </SwiperSlide>
                        <SwiperSlide>
                          <div className="swiper-slide">
                            <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                          </div>
                        </SwiperSlide>
                        <SwiperSlide>
                          <div className="swiper-slide">
                            <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                          </div>
                        </SwiperSlide>

                      </div>
                      <div className="swiper-pagination"></div>
                    </div>
                  </Swiper>
                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default OwnerDashBoard;