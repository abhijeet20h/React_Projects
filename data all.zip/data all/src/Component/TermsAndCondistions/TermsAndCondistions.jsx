import React from 'react';
import Layout from '../Layout/Layout';

const TermsAndCondistions = () => {
    return (
        <Layout>
            <div id="terms-and-conditions-section" className="blogs-details-section terms-and-conditions-section container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">


                    <div className="row">
                        <div className="col-12 pb-2 pt-0 pl-lg-4">
                            <h2 className="text-start text-lg-start mb-2 mb-lg-2 text-purple fw-bold">
                                Terms and Conditions
                            </h2>
                        </div>
                    </div>


                    <div className="row">
                        <div className="col-12">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper grow-card-img1"
                            >
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 py-4 pb-0">
                            <div className="static-wrap">
                                <p><b>Effective Date: </b> August 15, 2021</p>
                                <p><i>Website Covered: www.dreamsredeveloped.com</i></p>
                            </div>

                            <div className="static-wrap">
                                <p><b>THE AGREEMENT:</b> The use of this website and services on this website provided byDreamsredeveloped Private Limited (hereinafter referred to as "<b>Owner</b>") are subjectto the following Terms &amp; Conditions (hereinafter the "<b>Terms of Service</b>"), all partsand sub-parts of which are specifically incorporated by reference here together withthe Privacy Policy. Following are the Terms of Service governing your use ofwww.dreamsredeveloped.com (the "<b>Website</b>"), all pages on the Website and anyservices provided by or on this Website ("<b>Services</b>").</p>

                                <p>By accessing either directly or through a hyperlink, the Website, and/ or purchasingsomething from us, you engage in our "Service" and agree to be bound by the Termsof Service including those additional terms and conditions and policies referencedherein and/or available by hyperlink. These Terms of Service apply to all users of thesite, including without limitation vendors, buyers, customers, merchants, browsersand/ or contributors of content. You acknowledge and agree that the Website mayuse your personal information in the manner described in our Privacy Policy whichsets forth how information collected about you is collected, used and stored</p>
                            </div>
                            <div className="static-wrap">
                                <ol>
                                    <li>
                                        <div className="static-wrap">
                                            <h3> DEFINITIONS</h3>
                                            <p>The parties referred to in these Terms of Service shall be defined as follows:</p>

                                            <ol type="a">
                                                <li> <p>Owner, Us, We: The Owner, as the creator, operator, and publisher of theWebsite, makes the Website, and certain Services on it, available to users.Dreamsredeveloped Private Limited, Owner, Us, We, Our, Ours and other first-person pronouns will refer to the Owner, as well as all employees and affiliates of theOwner.</p></li>
                                                <li>
                                                    <p>You, the User, the Client: You, as the user of the Website, will be referred tothroughout these Terms of Service with second-person pronouns such as You, Your,Yours, or as User or Client. For the purpose of these Terms of Service, the term"User" or "you" shall mean any natural or legal person who person is accessing theWebsite. The term '"Your" shall be construed accordingly.</p>
                                                </li>
                                                <li>
                                                    <p>Parties: Collectively, the parties to these Terms of Service (the Owner and You)will be referred to as Parties.</p>
                                                </li>
                                            </ol>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>ASSENT &amp; ACCEPTANCE</h3>
                                            <p>y using the Website, You warrant that You have read and reviewed these Terms ofService and that You agree to be bound by it. If You do not agree to be bound bythese Terms of Service, please leave the Website immediately. The Owner onlyagrees to provide use of this Website and Services to You if You assent to theseTerms of Service. Further, based on the Services obtained by a User, additionalterms and conditions in respect of the specific Services may apply, which shall bedeemed an agreement between the Users and the Owner.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>AGE RESTRICTION</h3>
                                            <p>You must be at least 18 (eighteen) years of age to use this Website or any Servicescontained herein. By using this Website, You represent and warrant that You are atleast 18 years of age and may legally agree to these Terms of Service. The Ownerassumes no responsibility or liability for any misrepresentation of Your age.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>ABOUT THE SITE</h3>
                                            <p>The Website is an online store which carries out sale of the following: Feasibility,Bidding,   Architectural   Services,   Legal   Services   and   other  allied   services  forRedevelopment. We reserve the right to refuse service or refuse to sell the productson the Website at our sole discretion to anyone for any reason at any time.The Website does not screen or censor the users who register on and access theWebsite. You assume all risks associated with dealing with other users with whomyou come in contact through the Website. You agree to use the Website only forlawful purposes without infringing the rights or restricting the use of this Website byany third party.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>LICENSE TO USE WEBSITE</h3>
                                            <p>The Owner may provide You with certain information as a result of Your use of theWebsite   or   Services.   Such   information   may   include   but   is   not   limited   to,documentation, data, or information developed by the Owner, and other materialswhich may assist in Your use of the Website or Services ("Owner Materials"). Subject to these Terms of Service, the Owner grants You a non-exclusive, limited, non-transferable and revocable license to use the Owner Materials solely in connectionwith Your use of the Website and Services. The Owner Materials may not be used forany other purpose and this license terminates upon Your cessation of use of theWebsite or Services or at the termination of these Terms of Service.</p>
                                            <p>You agree not to collect contact information of other Users from the Website ordownload or copy any information by means of unsolicited access so as tocommunicate directly with them or for any reason whatsoever.</p>
                                            Any unauthorized use by you shall terminate the permission or license granted to youby the Website and You agree that you shall not bypass any measures used by theOwner to prevent or restrict access to the Website.
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>INTELLECTUAL PROPERTY</h3>
                                            <p>ou agree that the Website and all Services provided by the Owner are the propertyof the Owner, including all copyrights, trademarks, trade secrets, patents and otherintellectual property ("Owner IP"). You agree that the Owner owns all right, title andinterest in and to the Owner IP and that You will not use the Owner IP for anyunlawful or infringing purpose. You agree not to reproduce or distribute the Owner IPin any way, including electronically or via registration of any new trademarks, tradenames, service marks or Uniform Resource Locators (URLs), without express writtenpermission from the Owner.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>PAYMENT &amp; FEES</h3>
                                            <p>Should You register for any of the paid Services on this website or purchase anyproduct or service on this website, You agree to pay Us the specific monetaryamounts required for that product or those Services. These monetary amounts("Fees") will be described to You during Your account registration and/or confirmationprocess. The final amount required for payment will be shown to You immediatelyprior to purchase.</p>

                                            <p>We reserve the right to refuse service or refuse to sell the products on the Website atour sole discretion to anyone for any reason at any time.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>ACCEPTABLE USE</h3>
                                            <p>You agree not to use the Website or Services for any unlawful purpose or anypurpose prohibited under this clause. You agree not to use the Website or Servicesin any way that could damage the Website, Services or general business of theOwner.</p>

                                            <ol type="a">
                                                <li>
                                                    <p>You further agree not to use the Website or Services:</p>
                                                    <ol type="I">
                                                        <li>
                                                            <p>To harass, abuse, or threaten others or otherwise violate any person's legal rights;</p>
                                                        </li>
                                                        <li>
                                                            <p>To violate any intellectual property rights of the Owner or any third party;</p>
                                                        </li>
                                                        <li>
                                                            <p>To upload or otherwise disseminate any computer viruses or other software thatmay damage the property of another</p>
                                                        </li>
                                                        <li>
                                                            <p>To perpetrate any fraud;</p>
                                                        </li>
                                                        <li>
                                                            <p>To engage in or create any unlawful gambling, sweepstakes, or pyramid scheme</p>
                                                        </li>
                                                        <li>
                                                            <p>To publish or distribute any obscene or defamatory material;</p>
                                                        </li>
                                                        <li>
                                                            <p>To publish or distribute any material that incites violence, hate or discriminationtowards any group;</p>
                                                        </li>
                                                        <li>
                                                            <p>To unlawfully gather information about others.</p>
                                                        </li>
                                                    </ol>
                                                </li>
                                            </ol>
                                            <p>You are prohibited from using the site or its content:</p>
                                            <ol type="a">
                                                <li>
                                                    <p>for any unlawful purpose;</p>
                                                </li>
                                                <li>
                                                    <p>to solicit others to perform or participate in any unlawful acts;</p>
                                                </li>
                                                <li>
                                                    <p>to infringe on anythird party's intellectual property or proprietary rights, or rights of publicity or privacy,whether knowingly or unknowingly</p>
                                                </li>
                                                <li>
                                                    <p>to violate any local, federal or internationallaw, statute, ordinance or regulation;</p>
                                                </li>
                                                <li>
                                                    <p>to harass, abuse, insult, harm, defame,slander, disparage, intimidate, or discriminate based on gender, sexual orientation,religion, ethnicity, race, age, national origin, or disability</p>
                                                </li>
                                                <li>
                                                    <p>to submit false ormisleading information or any content which is defamatory, libelous, threatening,unlawful,   harassing,   indecent,   abusive,   obscene,   or   lewd   and   lascivious   orpornographic, or exploits minors in any way or assists in human trafficking or contentthat would violate rights of publicity and/or privacy or that would violate any law;</p>
                                                </li>
                                                <li>
                                                    <p>toupload or transmit viruses or any other type of malicious code that will or may beused in any way that will affect the functionality or operation of the Service or of anyrelated website, other websites, or the Internet;</p>
                                                </li>
                                                <li>
                                                    <p>to collect or track the personalinformation of others;</p>
                                                </li>
                                                <li>
                                                    <p>to damage, disable, overburden, or impair the Website orany other party's use of the Website; (j) to spam, phish, pharm, pretext, spider, crawl,or scrape;</p>
                                                </li>
                                                <li>
                                                    <p>for any obscene or immoral purpose; or</p>
                                                </li>
                                                <li>
                                                    <p>to interfere with orcircumvent the security features of the Service or any related website, other websites, or the Internet;</p>
                                                </li>
                                                <li>
                                                    <p>to personally threaten or has the effect of personallythreatening other Users. We reserve the right to terminate your use of the Service orany related website for violating any of the prohibited uses. The Company has the fullauthority to review all content posted by Users on the Website. You acknowledgethat the Website is not responsible or liable and does not control the content of anyinformation that may be posted to the Website by You or other User of the Websiteand you are solely responsible for the same. You agree that You shall not upload,post, or transmit any content that you do not have a right to make available (such as,the intellectual property of another party).</p>
                                                </li>
                                            </ol>
                                            <p>You agree to comply with all applicable laws, statutes and regulations concerningyour use of the Website and further agree that you will not transmit any information,data, text, files, links, software, chats, communication or other materials that areabusive, invasive of another's privacy, harassing, defamatory, vulgar, obscene,unlawful, false, misleading, harmful, threatening, hateful or racially or otherwiseobjectionable, including without limitation material of any kind or nature thatencourages conduct that could constitute a criminal offence, give rise to civil liabilityor otherwise violate any applicable local, state, provincial, national, or internationallaw or regulation, or encourage the use of controlled substances.</p>

                                            <p>We may, but have no obligation to, monitor, edit or remove content that we determinein our sole discretion are unlawful, offensive, threatening, libellous, defamatory,pornographic, obscene or otherwise objectionable or violates any party's intellectualproperty or these Terms of Service.</p>

                                            <p>You may not use our products for any illegal or unauthorized purpose nor may you, inthe use of the Service, violate any laws in your jurisdiction (including but not limited tocopyright laws).</p>

                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>COMMUNICATION</h3>

                                            <p>You understand that each time uses the Website in any manner, you agree to theseTerms. By agreeing to these Terms, you acknowledge that you are interested inavailing and purchasing the Services that you have selected and consent to receivecommunications via phone or electronic records from the Website including e-mailmessages telling you about products and services offered by the Website (or itsaffiliates and partners) and understanding your requirements. Communication canalso be by posting any notices on the Website. You agree that the communicationssent to You by the Website shall not be construed as spam or bulk under any lawprevailing in any country where such communication is received.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3> PRIVACY INFORMATION</h3>
                                            <p>Through Your Use of the Website and Services, You may provide Us with certaininformation. By using the Website or the Services, You authorize the Owner to useYour information in India and any other country where We may operate.</p>

                                            <ol type="a">
                                                <li>
                                                    <p>Information We May Collect or Receive: Depending on how You use Our Websiteor Services, We may receive information from external applications You use toaccess   Our   Website,   or   We   may   receive   information   through   various   webtechnologies, such as cookies, log files, clear gifs, web beacons or others.</p>
                                                </li>
                                                <li>
                                                    <p>How We Use Information: We use the information gathered from You to ensureYour continued good experience on Our website. We may also track certain of thepassive information received to improve Our marketing and analytics, and for this,We may work with third-party providers, including other marketers.</p>
                                                </li>
                                                <li>
                                                    <p>How You Can Protect Your Information: If You would like to disable Our access toany passive information We receive from the use of various technologies, You maychoose to disable cookies in Your web browser.</p>
                                                </li>
                                            </ol>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>ASSUMPTION OF RISK</h3>
                                            <p>The Website and Services are provided for communication purposes only. Youacknowledge and agree that any information posted on Our Website is not intendedto be legal advice, medical advice, or financial advice, and no fiduciary relationshiphas been created between You and the Owner. You further agree that Your purchaseof any of the products on the Website is at Your own risk. The Owner does notassume responsibility or liability for any advice or other information given on theWebsite.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>SALE OF GOODS/SERVICES</h3>
                                            <p>The Owner may sell goods or services or allow third parties to sell goods or serviceson the Website. The Owner undertakes to be as accurate as possible with allinformation regarding the goods and services, including product descriptions andimages. However, the Owner does not guarantee the accuracy or reliability of anyproduct information and You acknowledge and agree that You purchase suchproducts at Your own risk.</p>

                                            <p>We will make reimbursements for returns without undue delay, and not later than:</p>

                                            <ol type="i">
                                                <li>
                                                    <p>30 days after the day we received back from you any goods supplied; or</p>
                                                </li>
                                                <li>
                                                    <p>(if earlier) 30 days after the day you provide evidence that you have returned thegoods; or</p>
                                                </li>
                                                <li>
                                                    <p>if there were no goods supplied, 30 days after the day on which we are informedabout your decision to cancel this contract.</p>
                                                </li>
                                            </ol>

                                            <p>We will make the reimbursement using the same means of payment as you used forthe initial transaction unless you have expressly agreed otherwise; in any event, youwill not incur any fees as a result of the reimbursement.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>REVERSE ENGINEERING &amp; SECURITY</h3>
                                            <p>You agree not to undertake any of the following actions:</p>
                                            <ol type="a">
                                                <li>
                                                    <p>Reverse engineer, or attempt to reverse engineer or disassemble any code orsoftware from or on the Website or Services;</p>
                                                </li>
                                                <li>
                                                    <p>Violate the security of the Website or Services through any unauthorized access,circumvention of encryption or other security tools, data mining or interference to anyhost, user or network.</p>
                                                </li>
                                            </ol>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>DATA LOSS</h3>
                                            <p> The Owner does not accept responsibility for the security of Your account or content.You agree that Your use of the Website or Services is at Your own risk.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>INDEMNIFICATION</h3>
                                            <p>You agree to defend and indemnify the Owner and any of its affiliates (if applicable)and hold Us harmless against any and all legal claims and demands, includingreasonable attorney's fees, which may arise from or relate to Your use or misuse ofthe Website or Services, Your breach of these Terms of Service, or Your conduct oractions. You agree that the Owner shall be able to select its own legal counsel andmay participate in its own defence if the Owner wishes.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>SPAM POLICY</h3>
                                            <p>You are strictly prohibited from using the Website or any of the Owner's Services forillegal spam activities, including gathering email addresses and personal informationfrom others or sending any mass commercial emails.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>THIRD-PARTY LINKS &amp; CONTENT</h3>
                                            <p>The Owner may occasionally post links to third-party websites or other services. Youagree that the Owner is not responsible or liable for any loss or damage caused as aresult of Your use of any third party services linked to from Our Website.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>MODIFICATION &amp; VARIATION</h3>
                                            <p>The Owner may, from time to time and at any time without notice to You, modifythese Terms of Service. You agree that the Owner has the right to modify theseTerms of Service or revise anything contained herein. You further agree that allmodifications to these Terms of Service are in full force and effect immediately uponposting on the Website and that modifications or variations will replace any priorversion of these Terms of Service unless prior versions are specifically referred to orincorporated into the latest modification or variation of these Terms of Service.</p>

                                            <ol type="a">
                                                <li>
                                                    <p>To the extent any part or sub-part of these Terms of Service is held ineffective orinvalid by any court of law, You agree that the prior, effective version of these Termsof Service shall be considered enforceable and valid to the fullest extent.</p>
                                                </li>
                                                <li>
                                                    <p>You agree to routinely monitor these Terms of Service and refer to the EffectiveDate posted at the top of these Terms of Service to note modifications or variations.You further agree to clear Your cache when doing so to avoid accessing a priorversion of these Terms of Service. You agree that Your continued use of the Websiteafter any modifications to these Terms of Service is a manifestation of Yourcontinued assent to these Terms of Service.</p>
                                                </li>
                                                <li>
                                                    <p>In the event that You fail to monitor any modifications to or variations of theseTerms of Service, You agree that such failure shall be considered an affirmativewaiver of Your right to review the modified Agreement.</p>
                                                </li>
                                            </ol>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>ENTIRE AGREEMENT</h3>
                                            <p>This Agreement constitutes the entire understanding between the Parties withrespect to any and all use of this Website. This Agreement supersedes and replaces all prior or contemporaneous agreements or understandings, written or oral,regarding the use of this Website.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>SERVICE INTERRUPTIONS</h3>
                                            <p>The Owner may need to interrupt Your access to the Website to performmaintenance or emergency services on a scheduled or unscheduled basis. Youagree that Your access to the Website may be affected by unanticipated orunscheduled downtime, for any reason, but that the Owner shall have no liability forany damage or loss caused as a result of such downtime.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>TERM, TERMINATION &amp; SUSPENSION</h3>
                                            <p>The Owner may terminate these Terms of Service with You at any time for anyreason, with or without cause. The Owner specifically reserves the right to terminatethese Terms of Service if You violate any of the terms outlined herein, including, butnot limited to, violating the intellectual property rights of the Owner or a third party,failing to comply with applicable laws or other legal obligations, and/or publishing ordistributing illegal material. If You have registered for an account with Us, You mayalso terminate these Terms of Service at any time by contacting Us and requestingtermination. Please keep in mind that any outstanding fees will still be due even aftertermination of Your account. At the termination of these Terms of Service, anyprovisions that would be expected to survive termination by their nature shall remainin full force and effect.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>NO WARRANTIES</h3>
                                            <p>You agree that Your use of the Website and Services is at Your sole and exclusiverisk and that any Services provided by Us are on an "As Is" basis. The Owner herebyexpressly disclaims any and all express or implied warranties of any kind, including,but not limited to the implied warranty of fitness for a particular purpose and theimplied warranty of merchantability. The Owner makes no warranties that theWebsite or Services will meet Your needs or that the Website or Services will beuninterrupted, error-free, or secure. The Owner also makes no warranties as to thereliability or accuracy of any information on the Website or obtained through theServices. You agree that any damage that may occur to You, through Your computersystem, or as a result of the loss of Your data from Your use of the Website orServices is Your sole responsibility and that the Owner is not liable for any suchdamage or loss.</p>

                                            <p>All information, software, products, services and related graphics are provided on thissite is "as is" and "as available" basis with without warranty of any kind, eitherexpressed or implied. The Website disclaims all warranties, expressed or impliedincluding, without limitation, all implied warranties of merchantability, fitness for aparticular purpose, title and non-infringement or arising from a course of dealing,usage, or trade practice. The company makes no representation about the suitabilityof the information, software, products, and services contained on this Website for anypurpose, and the inclusion or offering of any products or services on this Websitedoes not constitute any endorsement or recommendation of such products orservices.</p>

                                            <p>The Website makes no warranty that the use of the Website will be uninterrupted,timely, secure, without defect or error-free. You expressly agree that use of the site isat your own risk. The Website shall not be responsible for any content found on theWebsite.</p>

                                            <p>Your use of any information or materials on this site or otherwise obtained throughuse of this Website is entirely at your own risk, for which we shall not be liable. It shallbe your own responsibility to ensure that any products, services or informationavailable through this website meet your specific requirements.</p>

                                            <p>The Website assumes no responsibility for the accuracy, currency, completeness orusefulness of information, views, opinions or advice in any material contained on theWebsite. Any information of third parties or advertisers is made available withoutdoing any changes and so the Website cannot guarantee accuracy and is not liableto any inconsistencies arising thereof. All postings, messages, advertisements,photos, sounds, images, text, files, video or other materials posted on, transmittedthrough, or linked from the Website, are solely the responsibility of the person fromwhom such Content originated and the Website does not control and is notresponsible for Content available on the Website.</p>

                                            <p>There may be instances when incorrect information is published inadvertently on ourWebsite or in the Service such as typographical errors, inaccuracies or omissionsthat may relate to product descriptions, pricing, promotions, offers, product shippingcharges, transit times and availability. Any errors, inaccuracies or omissions, may becorrected at our discretion at any time and we may change or update information orcancel orders if any information in the Service or on any related website is inaccurateat any time without prior notice (including after you have submitted your order).</p>

                                            <p>We undertake no obligation to update, amend or clarify information in the Service oron any related website, including without limitation, pricing information, except asrequired by law. No specified update or refresh date applied in the Service or on any related website should be taken to indicate that all information in the Service or onany related website has been modified or updated.</p>

                                            <p>The Website shall not be responsible for any interaction between you and the otherusers of the Website. Under no circumstances will the Website be liable for anygoods, services, resources or content available through such third party dealings orcommunications, or for any harm related thereto. The Website is under no obligationto become involved in any disputes between you and other users of the Website orbetween you and any other third parties. You agree to release the Website from anyand all claims, demands, and damages arising out of or in connection with suchdispute.</p>

                                            <p>You agree and understand that while the Website has made reasonable efforts tosafeguard the Website, it cannot and does not ensure or make any representationsthat the Website or any of the information provided by You cannot be hacked by anyunauthorised third parties. You specifically agree that the Website shall not beresponsible for unauthorized access to or alteration of Your transmissions or data,any material or data sent or received or not sent or received, or any transactionsentered into through the Website.</p>

                                            <p>You hereby agree and confirm that the Website shall not be held liable or responsiblein any manner whatsoever for such hacking or any loss or damages suffered by youdue to unauthorized access of the Website by third parties or for any such use of theinformation provided by You or any spam messages or information that You mayreceive from any such unauthorised third party (including those which are althoughsent representing the name of the Website but have not been authorized by theWebsite) which is in violation or contravention of this Terms of Service or the PrivacyPolicy.</p>

                                            <p>You specifically agree that the Website is not responsible or liable for anythreatening, defamatory, obscene, offensive or illegal content or conduct of any otherparty or any infringement of another's rights, including intellectual property rights. Youspecifically agree that the Website is not responsible for any content sent usingand/or included in the Website by any third party.</p>

                                            <p>The Website has no liability and will make no refund in the event of any delay,cancellation, strike, force majeure or other causes beyond their direct control, andthey have no responsibility for any additional expense omissions delays or acts ofany government or authority.</p>

                                            <p>You will be solely responsible for any damages to your computer system or loss ofdata that results from the download of any information and/or material. Some jurisdictions do not allow the exclusion of certain warranties, so some of the aboveexclusions may not apply to you.</p>

                                            <p>In no event shall the Website be liable for any direct, indirect, punitive, incidental,special, consequential damages or any damages whatsoever including, withoutlimitation, damages for loss of use, data or profits, arising out of or in any wayconnected with the use or performance of the site, with the delay or inability to usethe site or related services, the provision of or failure to provide Services, or to deliverthe products or for any information, software, products, services and related graphicsobtained through the site, or any interaction between you and other participants ofthe Website or otherwise arising out of the use of the Website, damages resultingfrom use of or reliance on the information present, whether based on contract, tort,negligence,   strict   liability   or   otherwise,   even   if   the   Website   or   any   of   itsaffiliates/suppliers has been advised of the possibility of damages. If despite thelimitation above, the Company is found liable for any loss or damage which arises outof or in any way connected with the use of the Website and/ or provision of Services,then the liability of the Company will in no event exceed, 50% (Fifty percent) of theamount you paid to the Company in connection with such transaction(s) on thisWebsite.</p>

                                            <p>You accept all responsibility for and hereby agree to indemnify and hold harmless thecompany from and against, any actions taken by you or by any person authorized touse your account, including without limitation, disclosure of passwords to thirdparties. By using the Website, you agree to defend, indemnify and hold harmless theindemnified parties from any and all liability regarding your use of the site orparticipation in any site's activities. If you are dissatisfied with the Website, or theServices or any portion thereof, or do not agree with these terms, your only recourseand exclusive remedy shall be to stop using the site.</p>



                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>LIMITATION ON LIABILITY</h3>
                                            <p>The Owner is not liable for any damages that may occur to You as a result of Youruse of the Website or Services, to the fullest extent permitted by law. The maximumliability of the Owner arising from or relating to these Terms of Service is limited tothe lesser of Rs. 1000 (Rupees One Thousand only) or the amount You paid to theOwner in the last six (6) months. This section applies to any and all claims by You,including, but not limited to, lost profits or revenues, consequential or punitivedamages, negligence, strict liability, fraud, or torts of any kind.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="static-wrap">
                                            <h3>GENERAL PROVISIONS:</h3>

                                            <ol type="a">
                                                <li>
                                                    <p>
                                                        <b>LANGUAGE:</b> All communications made or notices given pursuant to these Termsof Service shall be in the English language.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>JURISDICTION, VENUE &amp; GOVERNING LAW: </b>Through Your use of the Websiteor Services, You agree that the laws of India shall govern any matter or disputerelating to or arising out of these Terms of Service, as well as any dispute of any kindthat may arise between You and the Owner, with the exception of its conflict of lawprovisions. In case any litigation specifically permitted under these Terms of Serviceis initiated, the Parties agree to submit to the exclusive jurisdiction of the courts atPune, India. The Parties agree that this choice of law, venue, and jurisdictionprovision is not permissive, but rather mandatory in nature. You hereby waive theright to any objection of venue, including assertion of the doctrine of forum non-conveniens or similar doctrine.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>SSIGNMENT: </b>This Agreement, or the rights granted hereunder, may not beassigned, sold, leased or otherwise transferred in whole or part by You. Should theseTerms of Service, or the rights granted hereunder, by assigned, sold, leased orotherwise transferred by the Owner, the rights and liabilities of the Owner will bindand inure to any assignees, administrators, successors and executors.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>SEVERABILITY: </b>If any part or sub-part of these Terms of Service is held invalid orunenforceable by a court of law or competent arbitrator, the remaining parts and sub-parts will be enforced to the maximum extent possible. In such condition, theremainder of these Terms of Service shall continue in full force.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>NO WAIVER: </b>In the event that We fail to enforce any provision of these Terms ofService, this shall not constitute a waiver of any future enforcement of that provisionor of any other provision. Waiver of any part or sub-part of these Terms of Servicewill not constitute a waiver of any other part or sub-part.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>HEADINGS FOR CONVENIENCE ONLY: </b>Headings of parts and sub-parts underthese Terms of Service are for convenience and organization, only. Headings shallnot affect the meaning of any provisions of these Terms of Service.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>NO AGENCY, PARTNERSHIP OR JOINT VENTURE: </b>No agency, partnership, orjoint venture has been created between the Parties as a result of these Terms ofService. No Party has any authority to bind the other to third parties.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>FORCE MAJEURE: </b>The Owner is not liable for any failure to perform due tocauses beyond its reasonable control including, but not limited to, acts of God, actsof civil authorities, acts of military authorities, riots, embargoes, acts of nature andnatural disasters, and other acts which may be due to unforeseen circumstances.
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <b>ELECTRONIC COMMUNICATIONS PERMITTED: </b>Electronic communications arepermitted to both Parties under these Terms of Service, including e-mail or fax. Forany   questions   or   concerns,   please   email   Us   at   the   following   address:ln@dreamsredeveloped.com.
                                                    </p>
                                                </li>
                                            </ol>


                                            <p><strong>"Given the nature of services, there will be no return and refund of the Services"</strong></p>
                                        </div>
                                    </li>
                                </ol>

                            </div>



                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default TermsAndCondistions