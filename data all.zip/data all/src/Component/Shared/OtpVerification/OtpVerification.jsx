import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios';
import Layout from '../../Layout/Layout'
import { useParams, useNavigate } from "react-router-dom";
import baseApi from '../../../environment/Config';
import { toast } from 'react-toastify';
import SuccesModal from "../Modal/succesModal";
import AdminRoutes from '../../../App/Route/RouteDetails';
import ConfigurationModal from '../Modal/ConfigurationModal';

const OtpVerification = () => {
    const navigate = useNavigate();
    const [pageHandle, setPageHandle] = useState()
    const [firstDigit, setFirstDigit] = useState("")
    const [secondDigit, setSecondDigit] = useState('')
    const [threeDigit, setThreeDigit] = useState('')
    const [fourthDigit, setFourthDigit] = useState('')
    const { roles } = useParams();
    const { mobileno } = useParams();
    const { page } = useParams();
    const contactMedium = mobileno
    const InputOne = useRef();
    const InputSecond = useRef();
    const InputThird = useRef();
    const InputFourth = useRef();

    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    const checkCotact = !regex.test(contactMedium)

    useEffect(() => {
        window.scrollTo(0, 0)
        InputOne.current.focus() // for input one focus
    }, [])

    // check otp is valid or not
    const handleChekOtp = async () => {
        if (checkCotact) {
            var data = JSON.stringify({
                "mobile": parseInt(contactMedium),
                "roles": parseInt(roles),
                "otp": `${firstDigit}${secondDigit}${threeDigit}${fourthDigit}`
            });

            var config = {
                method: 'post',
                url: `${baseApi.baseUrl}user/otpvarification`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            await axios(config)
                .then(function (response) {
                    if (response.data.status === 1) {
                        localStorage.setItem("drvalid", JSON.stringify(response.data.data))
                        window.$('#popup-contact-successful').modal('show')
                        setTimeout(
                            showPopUp, 3000)
                    } else {
                        toast(response.data.message);
                    }
                })
                .catch(function (error) {
                    if (error?.response) {
                        toast(error.response.data.message);
                        resetState('mobile')
                    }
                });
        } else {
            var emaildata = JSON.stringify({
                "email": contactMedium,
                "roles": parseInt(roles),
                "otp": `${firstDigit}${secondDigit}${threeDigit}${fourthDigit}`
            });

            var configemail = {
                method: 'post',
                url: `${baseApi.baseUrl}user/otpvarification`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: emaildata
            };

            await axios(configemail)
                .then(function (response) {
                    if (response.data.status === 1) {
                        localStorage.setItem("drvalid", JSON.stringify(response.data.data))
                        window.$('#popup-contact-successful').modal('show')
                        setTimeout(
                            showPopUp, 3000)
                    } else {
                        toast(response.data.message);
                    }

                })
                .catch(function (error) {
                    if (error?.response) {
                        toast(error.response.data.message);
                        resetState('mail')
                    }
                });
        }

    }

    const resetState = (val) => {
        console.log("reset", val)
        setPageHandle("")
        setFirstDigit("")
        setSecondDigit('')
        setThreeDigit('')
        setFourthDigit('')
    }

    // modal close progamaticlly
    const showPopUp = () => {
        window.$('#popup-contact-successful').modal('hide')
        if (roles === '3') {
            navigate(AdminRoutes.DevloperDashboard)
        }
        if (roles === '1' && page === 'registr') {
            // navigate(AdminRoutes.SocietyConfigration)
            window.$('#popup-society-configuration').modal('show')
        }

        if (roles === '1' && page !== 'registr') {
            navigate(AdminRoutes.ChairmanDashboard)
        }
    }


    // for the resend otm api
    const handleresend = async () => {
        if (checkCotact) {
            var data = JSON.stringify({
                "mobile": parseInt(contactMedium),
                "roles": parseInt(roles) // for devloper role set 3
            });

            var config = {
                method: 'post',
                url: `${baseApi.baseUrl}user/resendotp`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            await axios(config)
                .then(function (response) {
                    if (response.data.status === 1) {
                        toast(response.data.message);
                    } else {
                        toast(response.data.message);
                    }
                })
                .catch(function (error) {
                    if (error?.response) {
                        toast(error.response.data.message);
                    }
                });
        } else {
            var emaildata = JSON.stringify({
                "email": contactMedium,
                "roles": parseInt(roles) // for devloper role set 3
            });

            var configemail = {
                method: 'post',
                url: `${baseApi.baseUrl}user/resendotp`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: emaildata
            };

            await axios(configemail)
                .then(function (response) {
                    if (response.data.status === 1) {
                        toast(response.data.message);
                    } else {
                        toast(response.data.message);
                    }
                })
                .catch(function (error) {
                    if (error?.response) {
                        toast(error.response.data.message);
                    }
                });
        }
    }


    useEffect(() => {
        if (pageHandle) {
            navigate(AdminRoutes.SocietyConfigration)
            setPageHandle(false)
            window.$('#popup-society-configuration').modal('hide')
        } else {
            setPageHandle(false)
            window.$('#popup-society-configuration').modal('hide')
        }
    }, [pageHandle])


    const handleFirstDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setFirstDigit(e.target.value)
            InputSecond.current.focus()
        } else {
            setFirstDigit(e.target.value)
        }
    }


    const handleSecondDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setSecondDigit(e.target.value)
            InputThird.current.focus()
        } else {
            setSecondDigit(e.target.value)
        }
    }


    const handleThirdDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setThreeDigit(e.target.value)
            InputFourth.current.focus()
        } else {
            setThreeDigit(e.target.value)
        }
    }


    const handleFourthDigit = (e) => {
        setFourthDigit(e.target.value)
    }


    return (
        <Layout>
            <div className="modal fade" id="popup-contact-successful" tabIndex="-1" aria-labelledby="popup-contact-successful" aria-hidden="true" >
                <SuccesModal HeaderMsg="Authentication Successful." informMsg="You have successfully login your account." />
            </div>
            <div className="modal fade" id="popup-society-configuration" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <ConfigurationModal setPageHandle={setPageHandle} />
            </div>
            <div id="chairman-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-center text-purple">{roles === "3" ? "Developer" : "Chairman"} {page === 'registr' ? "Registration" : 'Login'}</h2>
                    <hr className="hr-custom-two mx-auto mb-5 mb-lg-5"></hr>

                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div className="card custom-form-card otp-card p-3 mx-auto">
                                <label className="form-label mb-2">Enter OTP send to {checkCotact ? `${contactMedium?.substring(0, 2)}****${contactMedium?.slice(-4)}` : `${contactMedium?.substring(0, 3)}****${contactMedium?.slice(-10)}`}</label>
                                <div className="row">
                                    <div className="col text-center">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="First name" maxLength="1" ref={InputOne} value={firstDigit} onChange={(e) => handleFirstDigit(e)} />
                                    </div>
                                    <div className="col text-cente">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="Last name" maxLength="1" ref={InputSecond} value={secondDigit} onChange={(e) => handleSecondDigit(e)} />
                                    </div>
                                    <div className="col text-cente">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="Last name" maxLength="1" ref={InputThird} value={threeDigit} onChange={(e) => handleThirdDigit(e)} />
                                    </div>
                                    <div className="col text-cente">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="Last name" maxLength="1" ref={InputFourth} value={fourthDigit} onChange={(e) => handleFourthDigit(e)} />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 mt-5 mt-lg-5 mb-2 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className="btn btn-purple-custom px-5 text-white" onClick={() => handleChekOtp()} >Verify</button>
                            </div>
                        </div>

                        <div className="col-12 mt-2 mt-lg-3">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <p className="mb-0">Didn’t receive OTP?</p>
                                <p className="mb-3 fw-500 cursor-pointer text-decoration-underline" onClick={(e) => handleresend(e)}>Re-send OTP</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </Layout>
    )
}

export default OtpVerification