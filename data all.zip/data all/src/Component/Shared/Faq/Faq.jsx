import React from 'react'
import AdminRoutes from '../../../App/Route/RouteDetails';
import { useNavigate } from "react-router-dom";

const Faq = () => {
  const navigate = useNavigate();
  return (
    <div id="faq-section" className="faq-section container-fluid">
      <div className="container-lg py-4 py-lg-5">
        <h2 className="text-center text-purple fw-bold pt-2 pt-lg-5">
          Frequently Asked Questions
        </h2>
        <hr className="hr-custom-one mx-auto mb-4 mb-lg-5" />
        <div className="accordion accordion-flush pb-3 pb-lg-5" id="accordionFlushExample">
          <div className="accordion-item">
            <h2 className="accordion-header" id="flush-headingOne">
              <button
                className="accordion-button collapsed fw-bold"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseOne"
                aria-expanded="false"
                aria-controls="flush-collapseOne"
              >
                Why Dreamsredeveloped?
              </button>
            </h2>
            <div
              id="flush-collapseOne"
              className="accordion-collapse collapse"
              aria-labelledby="flush-headingOne"
              data-bs-parent="#accordionFlushExample"
            >
              <div className="accordion-body text-333333">
                <p>
                  Dreamsredeveloped presents to you the most simplified way to complete your Dream Redevelopment process. We ensure end-to-end hassle-free process for Developers and the societies.
                </p>
                <p>Advantages for Developers:</p>
                <ol className="text-14">
                  <li>Discovery - Instant access to the list of societies available in the city</li>
                  <li>Detailed case history about the Society/ Residents as required for Redevelopment.</li>
                  <li>Transparent presentation of Readiness of Society Members</li>
                  <li>Requirements of Society Members spelt out clearly with our unique Bidding Platform ensuring all parameters and easy to compare.</li>
                  <li>Receive reviews, and ratings from Societies/ Residents.</li>
                </ol>
                <p>Advantages for Residents/ Societies:</p>
                <ol className="text-14">
                  <li>Know your basic feasibility at the click of a button.</li>
                  <li>Select Experts at one place in a single Platform.</li>
                  <li>Discovery - Detailed information and ratings on developers.</li>
                  <li>100% support during the negotiation process.</li>
                  <li>Hassle-free comparison of biddings by various developers.</li>
                  <li>Pre-drafted Agreements.</li>
                  <li>Efficient Timeline.</li>
                </ol>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <h2 className="accordion-header" id="flush-headingTwo">
              <button
                className="accordion-button collapsed fw-bold"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseTwo"
                aria-expanded="false"
                aria-controls="flush-collapseTwo"
              >
                Our Services
              </button>
            </h2>
            <div
              id="flush-collapseTwo"
              className="accordion-collapse collapse"
              aria-labelledby="flush-headingTwo"
              data-bs-parent="#accordionFlushExample"
            >
              <div className="accordion-body text-333333">
                <ol className="text-14">
                  <li>Feasibility – Financial/ Architectural/ Regulatory</li>
                  <li>Bidding, Proposal Comparison and Ranking.</li>
                  <li>Agreements</li>
                  <li>One-stop shop for your Redevelopment needs.</li>
                </ol>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <h2 className="accordion-header" id="flush-headingThree">
              <button
                className="accordion-button collapsed fw-bold"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseThree"
                aria-expanded="false"
                aria-controls="flush-collapseThree"
              >
                How Dreamsredeveloped Works?
              </button>
            </h2>
            <div
              id="flush-collapseThree"
              className="accordion-collapse collapse"
              aria-labelledby="flush-headingThree"
              data-bs-parent="#accordionFlushExample"
            >
              <div className="accordion-body text-333333">
                <p>
                  If you have doubts with the subscription process, you can directly reach us on what’s app and our customer care executives will guide you through the whole process.
                </p>
                <p> <span className='text-decoration-underline cursor-pointer' onClick={() => navigate(AdminRoutes?.CommunityRegister)}>Click here</span> to get to Sign up. Select whether you want to register as Developer or Society.</p>
                <p className="fw-bold mb-2">A. Society</p>
                <p>You will select user type, if you are enthusiastic Flat owner then select flatowner, if you are secretarty then select secretary. Add your valid Mobile number and validate it by OTP, you account is created!
                  You can follow the steps ahead to create your Dreams Profile.</p>
                <p className="fw-bold mb-2">B. Developer</p>
                <p>You need to add your name, Email & set password, and hit Sign up button.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  )
}

export default Faq