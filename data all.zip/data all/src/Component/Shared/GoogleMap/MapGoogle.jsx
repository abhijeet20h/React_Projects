import React, { useState, useEffect } from 'react';
import { Map, Marker, GoogleApiWrapper } from 'google-maps-react';
import PlacesAutocomplete, {
    geocodeByAddress,
    getLatLng,
} from 'react-places-autocomplete';

const MapGoogle = (props) => {
    const [address, setAddress] = useState('');
    // const [showingInfoWindow, setShowingInfoWindow] = useState(false);
    // const [activeMarker, setActiveMarker] = useState({});
    // const [selectedPlace, setSelectedPlace] = useState({});
    const [currentLatitude, setCurrentLatitude] = useState(0);
    const [currentLongitude, setCurrentLongitude] = useState(0)
    const [mapCenter, setMapCenter] = useState({ lat: "", lng: "" })

    useEffect(() => {
        navigator.geolocation.getCurrentPosition(function (position) {
            setCurrentLatitude(position.coords.latitude);
            setCurrentLongitude(position.coords.longitude)
            setMapCenter({ ...mapCenter, lat: position.coords.latitude, lng: position.coords.longitude })
        });
    }, [])


    const handleChange = address => {
        setAddress(address)
    };

    const handleSelect = address => {
        // set name of address
        setAddress(address)
        geocodeByAddress(address)
            .then(results => getLatLng(results[0]))
            .then(latLng => {
                props.setGetDetails(latLng)
                // update center state
                setMapCenter(latLng)
            })
            .catch(error => console.error('Error', error));
    };

    // set current location
    const handleLocation = (e) => {
        setMapCenter({ ...mapCenter, lat: currentLatitude, lng: currentLongitude })
    }


    return (
        <div id='googleMaps' style={{ width: "100%", height: "400px", position: "relative", marginBottom: "50px" }}>
            <PlacesAutocomplete
                value={address}
                onChange={handleChange}
                onSelect={handleSelect}
            >
                {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
                    <div>
                        <input
                            {...getInputProps({
                                placeholder: 'Search Places ...',
                                className: 'form-control location-search-input mb-3',
                            })}
                        />
                        <div className="autocomplete-dropdown-container position-absolute start-0 w-100" style={{zIndex:'99999', top: '34px'}}>	
                            {loading && <div>Loading...</div>}
                            {suggestions.map(suggestion => {
                                const className = suggestion.active
                                    ? 'suggestion-item--active'
                                    : 'suggestion-item';
                                // inline style for demonstration purpose
                                const style = suggestion.active
                                ? { backgroundColor: '#fafafa', cursor: 'pointer', padding: '5px', border: '1px solid #eee', backgroundColor: '#F1F1F1', zIndex:'99999' }	
                                : { backgroundColor: '#ffffff', cursor: 'pointer', padding: '5px', border: '1px solid #eee', backgroundColor: '#FBFBFB', zIndex:'99999'};
                                return (
                                    <div key={suggestion.description}
                                        {...getSuggestionItemProps(suggestion, {
                                            className,
                                            style,
                                        })}
                                    >
                                        <span>{suggestion.description}</span>
                                    </div>
                                );
                            })}

                        </div>
                        <span className="dropdown-item list cursor-pointer position-absolute fw-500 d-block" style={{zIndex:'99997', top:"45px",left:"10px"}} onClick={handleLocation}><i className="fa fa-map-marker" aria-hidden="true"></i> Detect current location</span>


                    </div>
                )}
            </PlacesAutocomplete>

            <Map
                google={props.google}
                initialCenter={{
                    lat: mapCenter.lat,
                    lng: mapCenter.lng
                }}
                center={{
                    lat: mapCenter.lat,
                    lng: mapCenter.lng
                }}
                style={{marginTop:"25px"}}
            >
                <Marker
                    position={{
                        lat: mapCenter.lat,
                        lng: mapCenter.lng
                    }} />
            </Map>
        </div>
    )
}

export default GoogleApiWrapper({
    apiKey: ('AIzaSyBlqPe1Q_z3dmRk64rF3eGVeq7Oqo60e0s')
})(MapGoogle);