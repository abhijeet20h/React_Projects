import React from 'react'

const SpinnerModal = (props) => {
    return (
        <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content bg-white border-white">
                <div className="modal-header border-bottom-0 justify-content-end"> <i className="fa fa-1x fa-times-circle cursor-pointer text-secondary" aria-hidden="true" data-bs-dismiss="modal" aria-label="Close"></i> </div>
                <div className="modal-body text-center text-purple mb-4">
                    <h3 className="mb-4 text-center text-purple">{props.HeaderMsg}</h3>
                    <div className="d-flex flex-column align-items-center">
                        <p className="text-purple">{props.informMsg}</p>
                        <div className="custom-spinner spinner-border text-purple" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SpinnerModal