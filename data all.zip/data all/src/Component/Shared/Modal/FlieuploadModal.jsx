import React from 'react'

const FlieuploadModal = () => {
  return (
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content bg-orange border-orange">
          <div className="modal-header border-bottom-0 justify-content-end"> <i className="fa fa-1x fa-times-circle text-white cursor-pointer" aria-hidden="true" data-bs-dismiss="modal" aria-label="Close"></i> </div>
          <div className="modal-body text-center text-white">
            <h3 className="mb-4 text-center">Select upload method</h3>
            <div className="d-flex justify-content-center">
              <div className="d-flex flex-column align-items-start">
                <p className="text-18"><i className="fa fa-camera" aria-hidden="true"></i><span> Open Camera</span></p>
                <p className="text-18"><span><i className="fa fa-picture-o" aria-hidden="true"></i></span><span> Choose from Gallery</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
  )
}

export default FlieuploadModal