import React from 'react';



const ConfigurationModal = (props) => {
  return (
    <div className="modal-dialog modal-dialog-centered">
      <div className="modal-content bg-white border-white">
        <div className="modal-header border-bottom-0 justify-content-end"> <i className="fa fa-1x fa-times-circle text-secondary cursor-pointer" aria-hidden="true" data-bs-dismiss="modal" aria-label="Close"></i> </div>
        <div className="modal-body text-center text-purple">
          <h3 className="mb-4 text-center">Society Configuration</h3>
          <p>Fill out the society information to help us curate a seamless experience for you moving forward</p>
          <div className="d-flex flex-column align-items-center">
            <button type="button" className="btn btn-purple-custom text-white px-5 mb-4 w-100 btn-societyconfigure" onClick={() => props.setPageHandle(true)}>Let’s configure</button>
            <button type="button" className="btn btn-white-custom px-5 mb-4 border-purple w-100 btn-societyconfigure" onClick={() => props.setPageHandle(false)}>Not now</button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ConfigurationModal