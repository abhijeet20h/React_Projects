import React, { useState, useEffect } from 'react';
import Layout from '../../Layout/Layout';
import Faq from '../../Shared/Faq/Faq';
import AdminRoutes from '../../../App/Route/RouteDetails';
import { useNavigate, useParams } from "react-router-dom";


const SocietyRegister = () => {
    const navigate = useNavigate();
    const [selectRole, setSelectRole] = useState(false);
    const { selectauth } = useParams()

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    //handle role which select
    const RoleHandle = (role) => {
        setSelectRole(role)
    }

    //for redirect login page
    const handleReDirectLogin = () => {
        console.log(selectRole)
        if (selectauth === 'login') {
            if (selectRole === "Chairman") {
                navigate(AdminRoutes.ChairmanLogin)
            }
            if (selectRole === 'Owner') {
                navigate(AdminRoutes.PropertyOwnerLogin)
            }
        }

        if (selectauth === 'register') {
            if (selectRole === "Chairman") {
                navigate(AdminRoutes.ChairmanRegister)
            }
            if (selectRole === 'Owner') {
                navigate(AdminRoutes.PropertyOwnerRegister)
            }
        }
    }

    //for redirect register page
    // const handleReDirectRegister = () => {
    //     if (selectRole === "Chairman") {
    //         navigate(AdminRoutes.ChairmanRegister)
    //     } else {
    //         navigate(AdminRoutes.PropertyOwnerRegister)
    //     }
    // }

    return (
        <Layout>
            <div id="login-section" className="container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-center text-lg-start mb-4 text-purple">Welcome to <strong>Dreams redeveloped </strong> Community </h2>
                    <hr className="hr-custom-one mx-auto ms-lg-0 mb-4 mb-lg-5 text-start text-lg-start"></hr>
                    <p className="fst-italic fw-normal text-16 text-purple text-center text-lg-start mb-5">You are registering for the society as…</p>


                    <div className="row g-3 g-lg-5 mb-4 justify-content-center">
                        <div className="col-6 col-sm-6 col-md-3">

                            <div className="d-flex flex-column align-items-center item-className-custom cursor-pointer" onClick={() => RoleHandle("Chairman")}>
                                <div className={selectRole === 'Chairman' ? "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center role-icon-active selectedIcon" : "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center cursor-pointer"}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="42.83" height="47.721" viewBox="0 0 42.83 47.721">
                                        <defs>
                                            <clipPath id="clipPath">
                                                <rect id="Rectangle_3942" data-name="Rectangle 3942" width="21.415" height="31.492" transform="translate(0)" fill="#fff" stroke="#707070" strokeWidth="1" />
                                            </clipPath>
                                        </defs>
                                        <g id="Group_8566" data-name="Group 8566" opacity="0.7">
                                            <path id="Path_5882" data-name="Path 5882" d="M7.342,22.045V6.468a1.171,1.171,0,0,1,.771-1.1L19.44,1.249a.586.586,0,0,1,.786.55V7.6l7.4,2.465a1.171,1.171,0,0,1,.8,1.111V22.045h2.342v2.342H5V22.045Zm2.342,0h8.2V4.307l-8.2,2.982Zm16.4,0V12.022L20.226,10.07V22.045Z" transform="translate(3.168 -1.214)" fill={selectRole === 'Chairman' ? "#fff" : '#311E46'} />
                                            <g id="Mask_Group_50" data-name="Mask Group 50" transform="translate(0 13.709)" clipPath="url(#clipPath)">
                                                <path id="Icon_awesome-hands" data-name="Icon awesome-hands" d="M11.721,14.024a1.831,1.831,0,1,0-2.93,2.2l2.181,2.907a.915.915,0,0,1-.086,1.2l-.733.733A.91.91,0,0,1,8.8,20.995l-5.14-6.17V6.331A1.831,1.831,0,0,0,0,6.331v12.5a2.75,2.75,0,0,0,.6,1.717l5.958,7.686a3.416,3.416,0,0,1,.6,1.242.9.9,0,0,0,.876.664h7.538a.918.918,0,0,0,.916-.916v-6.41a7.337,7.337,0,0,0-1.465-4.4ZM34.8,4.5a1.83,1.83,0,0,0-1.831,1.831v8.493l-5.14,6.17a.919.919,0,0,1-1.351.063l-.733-.733a.915.915,0,0,1-.086-1.2l2.181-2.907a1.831,1.831,0,0,0-2.93-2.2l-3.3,4.4a7.337,7.337,0,0,0-1.465,4.4v6.41a.918.918,0,0,0,.916.916H28.6a.9.9,0,0,0,.876-.664,3.416,3.416,0,0,1,.6-1.242l5.958-7.686a2.75,2.75,0,0,0,.6-1.717V6.331A1.83,1.83,0,0,0,34.8,4.5Z" transform="translate(3.302 -0.463)" fill={selectRole === 'Chairman' ? "#fff" : '#311E46'} />
                                            </g>
                                            <g id="Mask_Group_51" data-name="Mask Group 51" transform="translate(21.415 16.228)" clipPath="url(#clipPath)">
                                                <path id="Icon_awesome-hands-2" data-name="Icon awesome-hands" d="M11.735,14.035a1.834,1.834,0,1,0-2.934,2.2l2.183,2.911a.916.916,0,0,1-.086,1.2l-.733.733a.911.911,0,0,1-1.352-.063L3.667,14.837v-8.5A1.834,1.834,0,0,0,0,6.334V18.848a2.753,2.753,0,0,0,.6,1.719l5.965,7.7a3.42,3.42,0,0,1,.6,1.243.9.9,0,0,0,.877.665h7.547a.92.92,0,0,0,.917-.917V22.837a7.346,7.346,0,0,0-1.467-4.4ZM34.839,4.5a1.832,1.832,0,0,0-1.834,1.834v8.5L27.86,21.014a.92.92,0,0,1-1.352.063l-.733-.733a.916.916,0,0,1-.086-1.2l2.183-2.911a1.834,1.834,0,0,0-2.934-2.2l-3.3,4.4a7.346,7.346,0,0,0-1.467,4.4v6.418a.92.92,0,0,0,.917.917h7.547a.9.9,0,0,0,.877-.665,3.42,3.42,0,0,1,.6-1.243l5.965-7.7a2.753,2.753,0,0,0,.6-1.719V6.334A1.832,1.832,0,0,0,34.839,4.5Z" transform="translate(-19.395 -2.98)" fill={selectRole === 'Chairman' ? "#fff" : '#311E46'} />
                                            </g>
                                        </g>
                                    </svg>

                                </div>
                                <p className="text-purple fw-500">Chairman</p>
                            </div>
                        </div>

                        <div className="col-6 col-sm-6 col-md-3">
                            <div className="d-flex flex-column align-items-center item-className-custom cursor-pointer" onClick={() => RoleHandle("Owner")}>
                                <div className={selectRole === 'Owner' ? "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center role-icon-active selectedIcon" : "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center cursor-pointer"}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="42.83" height="47.721" viewBox="0 0 42.83 47.721">
                                        <defs>
                                            <clipPath id="clipPath">
                                                <rect id="Rectangle_3945" data-name="Rectangle 3945" width="21.415" height="31.492" fill={selectRole === 'Owner' ? "#fff" : '#381f54'} stroke="#707070" strokeWidth="1" />
                                            </clipPath>
                                        </defs>
                                        <g id="Group_8567" data-name="Group 8567" opacity="0.7">
                                            <path id="Path_5883" data-name="Path 5883" d="M26.23,24.526H9.718a1.179,1.179,0,0,1-1.179-1.179V12.731H5L17.18,1.659a1.179,1.179,0,0,1,1.588,0l12.18,11.073H27.409V23.346a1.179,1.179,0,0,1-1.179,1.179ZM10.9,22.167H25.05V10.558L17.974,4.125,10.9,10.558Z" transform="translate(3.306 -1.352)" fill={selectRole === 'Owner' ? "#fff" : '#311E46'} />
                                            <g id="Mask_Group_53" data-name="Mask Group 53" transform="translate(0 13.709)" clipPath="url(#clipPath)">
                                                <path id="Icon_awesome-hands" data-name="Icon awesome-hands" d="M11.721,14.024a1.831,1.831,0,1,0-2.93,2.2l2.181,2.907a.915.915,0,0,1-.086,1.2l-.733.733A.91.91,0,0,1,8.8,20.995l-5.14-6.17V6.331A1.831,1.831,0,0,0,0,6.331v12.5a2.75,2.75,0,0,0,.6,1.717l5.958,7.686a3.416,3.416,0,0,1,.6,1.242.9.9,0,0,0,.876.664h7.538a.918.918,0,0,0,.916-.916v-6.41a7.337,7.337,0,0,0-1.465-4.4ZM34.8,4.5a1.83,1.83,0,0,0-1.831,1.831v8.493l-5.14,6.17a.919.919,0,0,1-1.351.063l-.733-.733a.915.915,0,0,1-.086-1.2l2.181-2.907a1.831,1.831,0,0,0-2.93-2.2l-3.3,4.4a7.337,7.337,0,0,0-1.465,4.4v6.41a.918.918,0,0,0,.916.916H28.6a.9.9,0,0,0,.876-.664,3.416,3.416,0,0,1,.6-1.242l5.958-7.686a2.75,2.75,0,0,0,.6-1.717V6.331A1.83,1.83,0,0,0,34.8,4.5Z" transform="translate(3.302 -0.463)" fill={selectRole === 'Owner' ? "#fff" : '#311E46'} />
                                            </g>
                                            <g id="Mask_Group_52" data-name="Mask Group 52" transform="translate(21.415 16.228)" clipPath="url(#clipPath)">
                                                <path id="Icon_awesome-hands-2" data-name="Icon awesome-hands" d="M11.735,14.035a1.834,1.834,0,1,0-2.934,2.2l2.183,2.911a.916.916,0,0,1-.086,1.2l-.733.733a.911.911,0,0,1-1.352-.063L3.667,14.837v-8.5A1.834,1.834,0,0,0,0,6.334V18.848a2.753,2.753,0,0,0,.6,1.719l5.965,7.7a3.42,3.42,0,0,1,.6,1.243.9.9,0,0,0,.877.665h7.547a.92.92,0,0,0,.917-.917V22.837a7.346,7.346,0,0,0-1.467-4.4ZM34.839,4.5a1.832,1.832,0,0,0-1.834,1.834v8.5L27.86,21.014a.92.92,0,0,1-1.352.063l-.733-.733a.916.916,0,0,1-.086-1.2l2.183-2.911a1.834,1.834,0,0,0-2.934-2.2l-3.3,4.4a7.346,7.346,0,0,0-1.467,4.4v6.418a.92.92,0,0,0,.917.917h7.547a.9.9,0,0,0,.877-.665,3.42,3.42,0,0,1,.6-1.243l5.965-7.7a2.753,2.753,0,0,0,.6-1.719V6.334A1.832,1.832,0,0,0,34.839,4.5Z" transform="translate(-19.395 -2.98)" fill={selectRole === 'Owner' ? "#fff" : '#311E46'} />
                                            </g>
                                        </g>
                                    </svg>

                                </div>
                                <p className="text-purple fw-500">Owner</p>
                            </div>
                        </div>

                        <div className="col-12 mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className={selectRole ? "btn btn-purple-custom px-5 text-white" : "btn btn-gray-custom px-5"} onClick={() => handleReDirectLogin()} >Next</button>
                                {/* <p className="mt-3"><span className="text-center text-purple hover-purple fw-bold cursor-pointer text-de text-decoration-underline" onClick={() => handleReDirectRegister()}>Register Now</span></p>*/}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            {/* <Faq /> */}
        </Layout>
    )
}

export default SocietyRegister