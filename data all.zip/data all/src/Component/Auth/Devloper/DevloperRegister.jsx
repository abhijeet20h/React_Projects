import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../../App/Route/RouteDetails';
import Layout from '../../Layout/Layout';

const DevloperRegister = () => {
    const navigate = useNavigate();
    const initialValues = { email: "", comname: "", Mobile: '' };
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setisSubmit] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
    };

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    //check validation
    const validate = (values) => {
        const errors = {};
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

        if (!values?.email) {
            errors.email = "Email is required!";
        } else if (!regex.test(values?.email)) {
            errors.email = "This is not a valid email format!";
        }
        if (!values?.Mobile) {
            errors.Mobile = "Enter Valid Mobile Number!";
        } else if (!values?.Mobile.match(/^(\+\d{1,3}[- ]?)?\d{10}$/)) {
            errors.Mobile = "Enter Valid Mobile Number!";
        }
        if (!values?.comname) {
            errors.comname = "Company Name is required!";
        }
        return errors;
    };


    // api calling
    useEffect(() => {
        if (Object.keys(formErrors).length === 0 && isSubmit) {
            navigate("/devloper_register_step1/" + formValues?.email + "/" + formValues?.comname + "/" + formValues?.Mobile)
        }
    }, [formErrors])


    // handle submit
    const handleNext = (e) => {
        e.preventDefault();
        setFormErrors(validate(formValues));
        setisSubmit(true);
    }

    return (
        <Layout>
            <div id="chairman-reg-section" className="container-fluid margin-top-first-container-large form-section">
                <div className="container-lg py-4 py-lg-5">
                    <h2 className="text-center text-purple">Developer Registration</h2>
                    <hr className="hr-custom-two mx-auto mb-4 mb-lg-5"></hr>
                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div className="card custom-form-card otp-card p-3 mx-auto">
                                <div className="row">
                                    <div className="col text-left">
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Enter email address.</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Email address" name='email' onChange={(e) => handleChange(e)} />
                                        <p className='text-danger mb-0'>{formErrors?.email}</p>
                                        <br></br>
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Company Name</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Company Name" maxLength="35" name='comname' onChange={(e) => handleChange(e)} />
                                        <p className='text-danger mb-0'>{formErrors?.comname}</p>
                                        <br></br>
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Mobile No.</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder='Enter Mobile No' maxLength="20" name='Mobile' onChange={(e) => handleChange(e)} />
                                        <p className='text-danger mb-0'>{formErrors?.Mobile}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 mt-5 mt-lg-5 mb-2 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className="btn btn-purple-custom px-5 text-white" onClick={(e) => handleNext(e)}>Next</button>
                            </div>
                        </div>
                        <div className="col-12 mt-2 mt-lg-3">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <p className="mb-0">Already a user? <span className='fw-500 cursor-pointer text-decoration-underline' onClick={() => navigate(AdminRoutes.DevloperLogin)}>Signin</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default DevloperRegister;