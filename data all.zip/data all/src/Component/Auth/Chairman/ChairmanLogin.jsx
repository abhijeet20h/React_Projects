import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import baseApi from "../../../environment/Config";
import Layout from '../../Layout/Layout';
import AdminRoutes from '../../../App/Route/RouteDetails';
import { toast } from 'react-toastify';

const DevloperLogin = () => {
    const navigate = useNavigate();
    const [mobileNo, setMobileNo] = useState(null)
    const [mobileErr, setMobileErr] = useState("")

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    // set valid mobile no
    const handleMobileNumber = (e) => {
        if (e.target.value.match(/^(\+\d{1,3}[- ]?)?\d{10}$/) && e.target.value) {
            setMobileNo(e.target.value)
            setMobileErr("")
        } else {
            setMobileNo(null)
            setMobileErr("Enter Valid Mobile Number")
        }
    }

    // otp send api 
    const handleSubmitMobile = () => {
        try {
            if (mobileNo) {
                var data = JSON.stringify({
                    "mobile":parseInt(mobileNo),
                    "roles": 1 // for devloper role set 2
                });

                var config = {
                    method: 'post',
                    url: `${baseApi.baseUrl}user/resendotp`,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: data
                };
  
                axios(config)
                    .then(function (response) {
                        if (response.data.status === 1) {
                            toast(response.data.message);
                            navigate('/otp_verification/' +mobileNo +'/' + 1 + '/Login')
                        } else {
                            toast(response.data.message);
                        }
                    })
                    .catch(function (error) {
                        if (error?.response) {
                            toast(error.response.data.message);
                        }
                    });
            } else {
                setMobileErr("Enter Valid Mobile Number")
            }
        } catch (err) {
            console.log(err)
        }

    }

    return (
        <Layout>
            <div id="developer-login-section" className="container-fluid margin-top-first-container-large form-section">
                <div className="container-lg py-4 py-lg-5">
                    <h2 className="text-center text-purple">Chairman Login</h2>
                    <hr className="hr-custom-two mx-auto mb-4 mb-lg-5"></hr>
                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div className="card custom-form-card otp-card p-3 mx-auto">
                                <div className="row">
                                    <div className="col text-center">
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Enter registered mobile no.</label>
                                        <input type="text" className="form-control mb-3" id="exampleFormControlInput1" placeholder="Enter digits" onChange={(e) => handleMobileNumber(e)} />
                                        <span className='text-danger mb-0'>{mobileErr}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 mt-5 mt-lg-5 mb-2 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className="btn btn-purple-custom px-5 text-white" onClick={() => handleSubmitMobile()}>Send OTP</button>
                            </div>
                        </div>
                        <div className="col-12 mt-2 mt-lg-3">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <p className="mb-0">New user? <span className="fw-500 cursor-pointer text-decoration-underline" onClick={() => navigate(AdminRoutes.ChairmanRegister)}>Register</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default DevloperLogin