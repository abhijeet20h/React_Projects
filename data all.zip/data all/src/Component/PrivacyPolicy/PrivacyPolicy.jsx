import React from 'react';
import Layout from '../Layout/Layout';

const PrivacyPolicy = () => {
    return (
        <Layout>
            <div id="privacy-policy-section" className="blogs-details-section privacy-policy-section container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">


                    <div className="row">
                        <div className="col-12 pb-2 pt-0 pl-lg-4">
                            <h2 className="text-start text-lg-start mb-2 mb-lg-2 text-purple fw-bold">
                                Privacy Policy
                            </h2>
                        </div>
                    </div>


                    <div className="row">
                        <div className="col-12">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper grow-card-img1"
                            >
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 py-4 pb-0">
                            <p className="pb-3">Dreams Redeveloped values user privacy. You will find all the information in compliance with personal data protection regulations here.</p>
                            <div className="static-wrap">
                                <h3>What are cookies and what do we use them for?</h3>
                                <p>A cookie or computer cookie is a small information file that is saved in your browser every time you visit our website.The usefulness of cookies is to save the history of your activity on our website, so that when you visit it again, it can identify you and configure its content based on your browsing habits, identity.</p>
                                <p>A cookie is harmless, it does not contain malicious or malicious code (eg viruses, Trojans, worms, etc.) that could harm your terminal (computer, smartphone, tablet, etc.), but it does have some impact on your right to protection. of your data, as it collects certain information concerning you (browsing habits, identity, preferences, etc.).</p>
                            </div>
                            <div className="static-wrap">
                                <h3>What information does a cookie store?</h3>
                                <p>Cookies do not usually collect special categories of personal data (sensitive data). The data they keep is technical, personal preferences, content personalization, etc.</p>
                            </div>
                            <div className="static-wrap">
                                <h3>What kind of cookies are there?</h3>
                                <p className="pb-3">In general, there are five types of cookies:</p>
                                <ul>
                                    <li>
                                        <h4>Technical cookies:</h4>
                                        <p>They are the most basic cookies. They allow the user to navigate through a web page, platform or application and to use the different options or services that exist in it, such as, for example, controlling traffic and data communication, identifying the session, accessing parts of restricted access, remember the elements that make up an order, carry out the purchase process of an order, make the request for registration or participation in an event, use security elements during navigation, store content for the broadcast of videos or sound or share content through social networks.</p>
                                    </li>
                                    <li>
                                        <h4>Personalization cookies:</h4>
                                        <p>They are those that allow the user to access the service with some predefined general characteristics based on a series of criteria in the user's terminal, such as the language, the type of browser through which the service is accessed, the regional configuration from where you access the service, etc.</p>
                                    </li>
                                    <li>
                                        <h4>Analysis cookies:</h4>
                                        <p>They are those that allow the person responsible for them to monitor and analyze the behavior of the users of the websites to which they are linked.</p>
                                        <p>The information collected through this type of cookies is used in the measurement of the activity of the websites, application or platform and for the elaboration of navigation profiles of the users of said sites, applications and platforms, in order to introduce improvements in function of the analysis of the usage data made by the users of the service.
                                        </p>
                                    </li>
                                    <li>
                                        <h4>Advertising cookies:</h4>
                                        <p>They are those that allow the management, in the most efficient way possible, of the advertising spaces that, where appropriate, the person responsible has included in a web page, application or platform from which the requested service is provided based on criteria such as content edited or the frequency at which the ads are displayed.</p>
                                    </li>
                                    <li>
                                        <h4>Behavioral advertising cookies:</h4>
                                        <p>They are those that allow the management, in the most efficient way possible, of the advertising spaces that, where appropriate, the person responsible has included in a web page, application or platform from which the requested service is provided.</p>
                                    </li>
                                </ul>
                                These cookies store information on user behavior obtained through continuous observation of their browsing habits, allowing the development of a specific profile to display advertising based on it.<p></p>
                            </div>
                            <div className="static-wrap">
                                <h3>What are own and third party cookies?</h3>
                                <ul>
                                    <li>
                                        <h4>Own cookies:</h4>
                                        <p>Own cookies are those that are generated and managed by the person responsible who provides the service requested by the user.</p>
                                    </li>
                                    <li>
                                        <h4>Third party cookies:</h4>
                                        <p>They are those that are generated by other entities other than the person responsible (services or external providers, such as Google).</p>
                                    </li>
                                </ul>
                            </div>
                            <div className="static-wrap">
                                <h3>What kind of cookies does our website save?</h3>
                                <p className="pb-3">Next, we proceed to relate the type of cookies stored on our website and their purpose:</p>
                                <ul>
                                    <li><b>_ga:</b> Google Analytics cookie that enables the unique visits control function. The first time a user enters the website through a browser, this cookie will be installed. When this user re-enters the web with the same browser, the cookie will consider that he is the same user. Only in the event that the user changes the browser will another user be considered.</li>
                                    <li><b>_gat:</b> This cookie is associated with Google Analytics. It is used to limit request speed - limiting data collection on high traffic sites. It expires after 10 minutes.</li>
                                    <li><b>_gid:</b> This cookie is associated with Google Analytics. It is used to distinguish users. It expires after 24 hours.</li>
                                </ul>
                            </div>
                            <div className="static-wrap pb-0">
                                <h3>What can I do with cookies?</h3>
                                <p className="pb-3">Cookies can be deleted, accepted or blocked, as desired, for this you only have to configure the web browser conveniently. At any time, you can prevent the installation of cookies (blocking) on your computer through the corresponding option in your browser, but in this case we cannot guarantee the correct operation of the different functionalities of our website.</p>
                                <p className="pb-3">Below, we provide the links for managing and blocking cookies depending on the browser you use:</p>
                                <ul>
                                    <li>Internet Explorer:<br></br><a className="text-primary" href="http://windows.microsoft.com/es-xl/internet-explorer/delete-manage-cookies#ie=ie-10">http://windows.microsoft.com/es-xl/internet-explorer/delete-manage-cookies#ie=ie-10</a></li>
                                    <li>FireFox:<br></br><a className="text-primary" href="https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop">https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop</a></li>
                                    <li>Chrome:<br></br><a className="text-primary" href="https://support.google.com/chrome/answer/95647?hl=en">https://support.google.com/chrome/answer/95647?hl=en</a></li>
                                    <li>Safari:<br></br><a className="text-primary" href="https://support.apple.com/en-in/guide/safari/sfri11471/mac">https://support.apple.com/en-in/guide/safari/sfri11471/mac</a></li>
                                </ul>
                                <p>You can also delete the cookies stored in your browser by going to its configuration options.</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </Layout>
    )
}

export default PrivacyPolicy