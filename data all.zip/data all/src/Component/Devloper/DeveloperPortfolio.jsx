import React, { useState, useEffect } from "react";
import Layout from '../Layout/Layout';
import baseApi from "../../environment/Config";
import axios from "axios";
import { toast } from 'react-toastify';
import MapGoogle from '../Shared/GoogleMap/MapGoogle';
import { useNavigate } from "react-router-dom";
import AdminRoutes from "../../App/Route/RouteDetails";

const DeveloperPortfolio = () => {
    const navigate = useNavigate();
    const [photo, setphoto] = useState("");
    const [ProjectImage, setProjectImage] = useState("");
    const [RoomImage, setRoomImage] = useState("");
    const [spinner, setSpinner] = useState(false)
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));

    const initialDevProtfolioValues = { Project_Name: "", Time_frame: "", Reg_no: "", Proj_Location: "", Specific_Amenities: "", Architect: "", Banker: "", Lawyer: "" };
    const [formDevProtfolioValues, setFormDevProtfolioValues] = useState(initialDevProtfolioValues);
    const [projectTag, setProgetTag] = useState("")
    const [isSubmit, setIsSubmit] = useState(false);

    //for grt googlr map valuds
    const [getDetails, setGetDetails] = useState({});
    const [latitude, setLatitude] = useState('');
    const [longitude, setLongitude] = useState('');

    // set defalut location
    useEffect(() => {
        navigator.geolocation.getCurrentPosition(function (position) {
            setLatitude(position.coords.latitude);
            setLongitude(position.coords.longitude);
        });
    }, [])

    // on change set data
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormDevProtfolioValues({ ...formDevProtfolioValues, [name]: value });
    };


    // uploade image
    const UploadDevImage = (setValue, e) => {
        setSpinner(false)
        var formdata = new FormData();
        formdata.append("file", e.target.files[0]);

        var requestOptions = {
            method: 'POST',
            body: formdata,
            redirect: 'follow'
        };

        fetch(`${baseApi.baseUrl}fileupload`, requestOptions)
            .then(response => response.text())
            .then(result => SetImage(JSON.parse(result).file_path, setValue))
            .catch(error => setSpinner(false));
    };

    //set Image Value 
    const SetImage = (image, setValue) => {
        setValue(image)
        setSpinner(false)
    }

    // update data and api call
    useEffect(() => {
        if (isSubmit) {
            try {
                var data = JSON.stringify({
                    "project_name": formDevProtfolioValues?.Project_Name,
                    "project_timeframe": formDevProtfolioValues?.Time_frame,
                    "project_image": photo,
                    "tag_project": projectTag,
                    "RERA_registration_no": formDevProtfolioValues?.Reg_no,
                    "project_location": formDevProtfolioValues?.Proj_Location,
                    "elevator_image": ProjectImage,
                    "room_image": RoomImage,
                    "project_highlights": formDevProtfolioValues?.Specific_Amenities,
                    "architect": formDevProtfolioValues?.Architect,
                    "banker": formDevProtfolioValues?.Banker,
                    "lawyer": formDevProtfolioValues?.Lawyer,
                    "location": getDetails

                });

                var config = {
                    method: 'put',
                    url: `${baseApi.baseUrl}user/updateuser/${userInfo._id}`,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: data
                };

                axios(config)
                    .then(function (response) {
                        toast("Profile Update Successfully");
                        navigate(AdminRoutes.DevloperDashboard)
                    })
            } catch (err) {
                console.log(err)
            }
        }

    }, [isSubmit])


    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmit(true);
    };


    return (
        <Layout>
            <div id="developer-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">
                    <h2 className="text-start text-lg-center text-purple">Developer Portfolio</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>


                    <div className="row gy-3 gy-lg-3">
                        <div className="col-12">
                            <h3 className="fw-600">Add a Project</h3>
                            <p className="mb-3">Showcase all your projects</p>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Project Name</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="ex. Avantika Coop Society" name="Project_Name" onChange={(e) => handleChange(e)} /> </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Timeframe of the Project</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input" placeholder="00" aria-label="Text input with dropdown button" name="Time_frame" onChange={(e) => handleChange(e)} />
                                    <span className="input-group-text" id="basic-addon2">Months</span>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <span className="custom-drag-box">
                                    <label className="form-label mb-2 fw-400">Photo</label>
                                    {spinner ?
                                        <>
                                            <span className="custom-drag-box" >
                                                <div className="spinner-grow text-warning" role="status">
                                                    <span className="sr-only">Loading...</span>
                                                </div>
                                                <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setphoto, e)} />
                                            </span>
                                        </>
                                        :
                                        <>
                                            {photo ?
                                                <>
                                                    <i className="fa fa-2x fa-check-circle me-2 text-orange text-20px d-block mb-2" aria-hidden="true"></i>
                                                    <span className="custom-drag-box-text">image Uploded</span>
                                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setphoto, e)} />
                                                </>
                                                :
                                                <>
                                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                                    <span className="custom-drag-box-text">Drop your image here</span>
                                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" name="photo" onChange={(e) => UploadDevImage(setphoto, e)} />
                                                </>
                                            }
                                        </>
                                    }
                                </span>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label className="form-label mb-2">Tag this project as</label>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="Landmark Projects" onChange={e => setProgetTag(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1"> Landmark Projects </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="Upcoming Projects" onChange={e => setProgetTag(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2"> Upcoming Projects </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="Completed Projects" onChange={e => setProgetTag(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios3"> Completed Projects </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="Ongoing Projects" onChange={e => setProgetTag(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios4"> Ongoing Projects </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">RERA Registration Number</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter Here" name="Reg_no" onChange={(e) => handleChange(e)} />
                            </div>
                        </div>
                    </div>

                    <hr className="my-5" />

                    <div className="row gy-3 gy-lg-3">
                        <div className="col-12 col-sm-12 col-md-12">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Project Location</label>
                                <MapGoogle setGetDetails={setGetDetails} />
                            </div>

                        </div>

                    </div>

                    <hr className="my-5" />

                    <div className="row gy-3 gy-lg-3">
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3"> <span className="custom-drag-box">
                                <label className="form-label mb-2 fw-400">Project & Elevation Images</label>
                                {spinner ?
                                    <>
                                        <span className="custom-drag-box" >
                                            <div className="spinner-grow text-warning" role="status">
                                                <span className="sr-only">Loading...</span>
                                            </div>
                                            <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setProjectImage, e)} />
                                        </span>
                                    </>
                                    :
                                    <>
                                        {ProjectImage ?
                                            <>
                                                <i className="fa fa-2x fa-check-circle me-2 text-orange text-20px d-block mb-2" aria-hidden="true"></i>
                                                <span className="custom-drag-box-text">image Uploded</span>
                                                <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setProjectImage, e)} />
                                            </>
                                            :
                                            <>
                                                <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                                <span className="custom-drag-box-text">Drop your image here</span>
                                                <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setProjectImage, e)} />
                                            </>
                                        }
                                    </>
                                }
                            </span>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3"> <span className="custom-drag-box">
                                <label className="form-label mb-2 fw-400">Room Images</label>
                                {spinner ?
                                    <>
                                        <span className="custom-drag-box" >
                                            <div className="spinner-grow text-warning" role="status">
                                                <span className="sr-only">Loading...</span>
                                            </div>
                                            <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setProjectImage, e)} />
                                        </span>
                                    </>
                                    :
                                    <>
                                        {
                                            RoomImage ?
                                                <>
                                                    < i className="fa fa-2x fa-check-circle me-2 text-orange text-20px d-block mb-2" aria-hidden="true"></i>
                                                    <span className="custom-drag-box-text">image Uploded</span>
                                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setRoomImage, e)} />
                                                </>
                                                :
                                                <>
                                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                                    <span className="custom-drag-box-text">Drop your image here</span>
                                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(setRoomImage, e)} />
                                                </>
                                        }
                                    </>
                                }
                            </span>
                            </div>
                        </div>
                    </div>

                    <hr className="my-5" />

                    <div className="row gy-3 gy-lg-3">
                        <div className="col-12 col-sm-12 col-md-12 col-lg-6">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Add any specific amenities that you have provided in this Project which you want to Highlight</label>
                                <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Amenities like Solar, Elevation, Rainwater Harvesting, etc" name="Specific_Amenities" onChange={(e) => handleChange(e)}></textarea>
                            </div>
                        </div>
                    </div>

                    <hr className="my-5" ></hr>

                    <div className="row gy-3 gy-lg-3">
                        <div className="col-12">
                            <h3 className="fw-600">Vendors</h3>
                            <p className="mb-3">Add your external and supporting vendor</p>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Architect</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="" name="Architect" onChange={(e) => handleChange(e)} /> </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Banker</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="" name="Banker" onChange={(e) => handleChange(e)} /> </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Lawyer</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="" name="Lawyer" onChange={(e) => handleChange(e)} /> </div>
                        </div>
                    </div>

                    <hr className="my-5"></hr>

                    <div className="row gy-3 gy-lg-3">

                        <div className="col-12">
                            <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                <button type="button" id="show-modal-button-1" className="btn btn-purple-custom px-5 text-white" onClick={(e) => handleSubmit(e)}>Submit</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div >

        </Layout >
    )
}

export default DeveloperPortfolio