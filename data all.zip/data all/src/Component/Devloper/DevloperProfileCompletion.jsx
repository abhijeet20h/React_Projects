import React from 'react';
import { useNavigate } from "react-router-dom";
import Layout from '../Layout/Layout';
import AdminRoutes from '../../App/Route/RouteDetails';

const DevloperProfileCompletion = () => {
    const navigate = useNavigate();
    return (
        <Layout>
            <div id="developer-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-start text-lg-center text-purple">Profile completion</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>

                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div>
                                <div className="d-flex flex-row justify-content-between mb-2"> <span
                                    className="fw-bold text-purple fw-500 text-18">Portfolio</span> <span
                                        className="fst-italic fw-normal text-16">2 set of questions only</span> </div>
                                <div className="progress mb-4 rounded-20">
                                    <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: '75%' }}
                                        aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 mt-0">
                            <p className="fw-600">Add your projects</p>
                            <p className="fw-400 fst-italic">Tell us something about your projects</p>
                        </div>
                        <div className="col-8 offset-2 col-sm-4 offset-sm-4  text-center">
                            <div className="card">
                                <div className="card-body text-purple d-flex flex-row align-items-center justify-content-center cursor-pointer" onClick={() => navigate(AdminRoutes.DeveloperPortfolio)}>
                                    <i className="fa fa-plus fs-4 me-2" aria-hidden="true"></i> Add New Project
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default DevloperProfileCompletion