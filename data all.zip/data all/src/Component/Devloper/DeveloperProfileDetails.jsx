import React, { useEffect,useState } from 'react';
import Layout from '../Layout/Layout';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';
import PlaceholderImage from '../../assets/images/Placeholder-image.png'
// import baseApi from "../../../environment/Config";

import axios from 'axios';
const DeveloperProfileDetails = () => {
    const navigate = useNavigate(); 
    const [posts, setPosts] = useState([]);
    const [DevData , setDevdata] = useState();
    useEffect(() => {
        window.scrollTo(0, 0)
        DevloperProfileDetatils()
    }, [])
//     useEffect(() => {
//     const url = `${baseApi.baseUrl}user/getinfobyid`; 
//     // url: `${baseApi.baseUrl}user/resendotp`,
//     const fetchData = async () => {
//         try {
//             const response = await fetch(url);
//             const json = await response.json();
//             console.log(  "@@@@1",json);
//         } catch (error) {
//             console.log("error @1", error);
//         }
//     };    
//     fetchData();
// }, []);

// const fetchPost = async () => {
// const response = await axios("http://43.205.53.236:4000/user/getinfobyid")
//     // setPosts(response.data)
//     console.log("@@@@@@" , response.data)
// }
// useEffect(() => {
//   fetchPost();
//  }, []);


const DevloperProfileDetatils = () => { 
    var data = JSON.stringify({
        "_id": "6305fb081992bd42244225be"
      });
      
      var config = {
        method: 'post',
        url: 'http://43.205.53.236:4000/user/getinfobyid',
        headers: { 
          'Content-Type': 'application/json'
        },
        data : data
      };
      
      axios(config)
      .then(function (response) {
        console.log(response.data.data);
        if(response.data.status === 1){
            setDevdata(response.data?.data[0])
        }
      })
      .catch(function (error) {
        console.log(error);
      });
}



    return (
        <Layout>
            <div className="container-fluid margin-top-first-container-small bg-white">
                <div className="container-lg py-4 py-lg-5">
                    {/* <h2 className="text-center text-purple">Developer Profile</h2>
                    <hr className="hr-custom-two mx-auto mb-4 mb-lg-5"></hr> */}
                    <div className="row gy-5 g-lg-5">
                    <div className="col-12 mt-5">
                            <div className="w-100 h-100 d-flex justify-content-between align-items-center">
                                <h5 className='d-inline-block cursor-pointer' onClick={() => navigate(AdminRoutes.DeveloperPayment)}><i className="fa fa-chevron-left" aria-hidden="true"></i> My Profile</h5>
                                <button className='btn btn-orange-custom' onClick={() => navigate(AdminRoutes.DeveloperProfileEdit)}>Edit</button>
                            </div>
                        </div>
                        <div className="col-12 py-4 mt-3 rounded-4 bg-gray-light1">
                            <div className="row">
                                <div className="col-12 col-lg-2 mb-3 mb-lg-auto">
                                    <div className='w-100 h-100 d-flex flex-column justify-content-center align-items-center'>
                                        <div className="p-3 rounded-circle developer-profile-details-developer-image" style={{ backgroundImage: `url(${PlaceholderImage})` }}></div>
                                    </div>
                                </div>
                                <div className="col-12 col-md-6 col-lg-5 mb-4 mb-lg-auto">
                                    <div className='w-100 h-100 d-flex flex-column justify-content-center align-items-center'>
                                        <h5 className='w-100 mb-3'><span className='fs-inherit d-inline-block w-50 d-inline-block text-end align-top fw-600'>Entity Name:</span><span className='fs-inherit w-50 d-inline-block text-start ps-2 fw-600'>{DevData?.entity_name}</span></h5>
                                        <p className='w-100'><span className='w-50 d-inline-block text-end align-top'>Company Name:</span><span className='w-50 d-inline-block text-start ps-2'>{DevData?.company_name}</span></p>
                                        <p className='w-100'><span className='w-50 d-inline-block text-end align-top'>Website:</span><span className='w-50 d-inline-block text-start ps-2 text-break'>{DevData?.email}</span></p>
                                        <p className='w-100'><span className='w-50 d-inline-block text-end align-top'>Mobile No:</span><span className='w-50 d-inline-block text-start ps-2'>{DevData?.mobile}</span></p>
                                        <p className='w-100'><span className='w-50 d-inline-block text-end align-top'>Address:</span><span className='w-50 d-inline-block text-start ps-2'>{DevData?.address}</span></p>
                                        <p className='w-100'><span className='w-50 d-inline-block text-end align-top'>Years in redevelopment:</span><span className='w-50 d-inline-block text-start ps-2'>{DevData?.redevelopment_year}</span></p>
                                        <p className='w-100'><span className='w-50 d-inline-block text-end align-top'>Years in services:</span><span className='w-50 d-inline-block text-start ps-2'> {DevData?.service_year} </span></p>
                                    </div>

                                </div>
                                <div className="col-12 col-md-6 col-lg-5 developerProfileLeftBorder">
                                    <h5 className='mb-3 text-center text-lg-start fw-600'>Your Expertise</h5>
                                    <p className='text-start'> {DevData?.expertise}</p>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 py-4 mt-3 rounded-4 bg-gray-light1">
                        <h5 className='text-center text-lg-start fw-600 mb-3'>Founder/ Partner Details</h5>
                            <div className="row gy-3">                                
                                <div className="col-12 col-sm-6 col-md-3 col-lg-3">
                                    <div className="card">
                                        <div className="p-3 rounded-circle developer-profile-details-founder-image" style={{ backgroundImage: `url(${PlaceholderImage})` }}></div>
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center mb-2">Harshad Hande</h5>
                                            <p className="card-text text-center mb-2"><span>Qualification:</span><span className='ms-1'>Civil Engineer</span></p>
                                            <p className="card-text text-center mb-2"><span>Years in services:</span><span className='ms-1'>3 years</span></p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-6 col-md-3 col-lg-3">
                                    <div className="card">
                                        <div className="p-3 rounded-circle developer-profile-details-founder-image" style={{ backgroundImage: `url(${PlaceholderImage})` }}></div>
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center">Harshad Hande</h5>
                                            <p className="card-text text-center mb-2"><span>Qualification:</span><span className='ms-1'>Civil Engineer</span></p>
                                            <p className="card-text text-center mb-2"><span>Years in services:</span><span className='ms-1'>3 years</span></p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-6 col-md-3 col-lg-3">
                                    <div className="card">
                                        <div className="p-3 rounded-circle developer-profile-details-founder-image" style={{ backgroundImage: `url(${PlaceholderImage})` }}></div>
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center">Harshad Hande</h5>
                                            <p className="card-text text-center mb-2"><span>Qualification:</span><span className='ms-1'>Civil Engineer</span></p>
                                            <p className="card-text text-center mb-2"><span>Years in services:</span><span className='ms-1'>3 years</span></p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-6 col-md-3 col-lg-3">
                                    <div className="card">
                                        <div className="p-3 rounded-circle developer-profile-details-founder-image" style={{ backgroundImage: `url(${PlaceholderImage})` }}></div>
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center mb-2">Harshad Hande</h5>
                                            <p className="card-text text-center mb-2"><span>Qualification:</span><span className='ms-1'>Civil Engineer</span></p>
                                            <p className="card-text text-center mb-2"><span>Years in services:</span><span className='ms-1'>3 years</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 py-4 mt-3 rounded-4 bg-gray-light1">
                        <h5 className='text-center text-lg-start fw-600 mb-4'>Verification Details</h5>
                            <div className="row gy-3">                                
                                <div className="col-12 col-sm-4 col-lg-3">
                                    <div className="card">
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center">Balance Sheet</h5>
                                            <p className="card-text text-center">View Document</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-4 col-lg-3">
                                    <div className="card">
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center">Income Tax Return</h5>
                                            <p className="card-text text-center">View Document</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-4 col-lg-3">
                                    <div className="card">
                                        <div className="card-body d-flex flex-column justify-content-center align-items-center">
                                            <h5 className="card-title text-center">CIBIL Score Report</h5>
                                            <p className="card-text text-center">View Document</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <div className="col-12 mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button className='btn btn-orange-custom' onClick={() => navigate(AdminRoutes.DeveloperProfileEdit)}>Edit</button>
                            </div>
                        </div> */}

                    </div>

                </div>
            </div>
        </Layout>
    )
}

export default DeveloperProfileDetails;