import React, { useEffect  , useState} from 'react';
import Layout from '../Layout/Layout';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';
import PlaceholderImage from '../../assets/images/Placeholder-image.png'
import axios from 'axios';

const DeveloperProfileEdit = () => {
    const [DevData , setDevdata] = useState();

    useEffect(() => {
        window.scrollTo(0, 0)
        DeveloperProfileEdit()
    }, [])
    const navigate = useNavigate();


    const DeveloperProfileEdit = () => {
        var data = JSON.stringify({
            "_id": "6305fb081992bd42244225be"
          });
          
          var config = {
            method: 'post',
            url: 'http://43.205.53.236:4000/user/getinfobyid',
            headers: { 
              'Content-Type': 'application/json'
            },
            data : data
          };
          
          axios(config)
          .then(function (response) {
            console.log(response.data.data);
            if(response.data.status === 1){
                setDevdata(response.data?.data[0])
            }
          })
          .catch(function (error) {
            console.log(error);
          });
    }

    useEffect(()=>{
        console.log(DevData)
    },[DevData])

    return (
        <Layout>
            <div className="container-fluid margin-top-first-container-small bg-white">
                <div className="container-lg py-4 py-lg-5">


                    {/* <h2 className="text-center text-purple">Developer Profile Edit</h2>
                    <hr className="hr-custom-two mx-auto mb-4 mb-lg-5"></hr> */}
                   
						
                    <div className="row g-3 g-lg-5">
                        <div className="col-12 mt-5">
                            <div className="w-100 h-100 d-flex justify-content-between align-items-center">
                                <h5 className='d-inline-block cursor-pointer' onClick={() => navigate(AdminRoutes.DeveloperPayment)}><i className="fa fa-chevron-left" aria-hidden="true"></i> My Profile</h5>
                                <button onClick={() => navigate(AdminRoutes.DeveloperProfileDetails)} className='btn btn-orange-custom'>Save</button>
                            </div>

                        </div>
                        <div className="col-12 mt-4">
                            <div className="row">
                                <div className="col-12 col-lg-2">
                                    <div className='w-100 h-100 d-flex flex-column justify-content-top align-items-center'>
                                    <label className="cursor-pointer">
                                        <div className="p-3 rounded-circle developer-profile-details-developer-image position-relative" style={{ backgroundImage: `url(${PlaceholderImage})` }}>
                                        <input type="file" className="d-none" id="input" name="image" accept="image/*" />
                                        <i className="fa fa-pencil-square-o position-absolute text-18 fw-bold" style={{bottom: "10px", right: "10px"}} aria-hidden="true"></i>
                                        </div>
                                    </label>
                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2"  >Entity Name</label>
                                            <input value={DevData?.entity_name}  type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Website</label>
                                            <input type="text" value={DevData?.Website} className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Email</label>
                                            <input  disabled value={DevData?.email} type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Mobile No.</label>
                                            <input disabled value={DevData?.mobile} type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12 mb-4">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Address:</label>
                                            <input value={DevData?.expertise} type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2" >Company Name</label>
                                            <input value={DevData?.company_name} type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Years in redevelopment</label>
                                            <div className="input-group mb-0">
                                                <input value={DevData?.redevelopment_year} type="text" className="form-control input-group-first-input"
                                                    placeholder="00" aria-label="Text input with dropdown button" name='yearinservice' />
                                                <span className="input-group-text" id="basic-addon2">Years</span>
                                            </div>
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Years in services</label>
                                            <div className="input-group mb-0">
                                                <input value={DevData?.service_year} type="text" className="form-control input-group-first-input"
                                                    placeholder="00" aria-label="Text input with dropdown button" name='yearinservice' />
                                                <span className="input-group-text" id="basic-addon2">Years</span>
                                            </div>
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Your expertise</label>
                                            <textarea value={DevData?.expertise} className="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Enter your vision & ambition here" name='expertise'></textarea>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                        <div className="col-12 mt-5">
                            <div className="w-100 h-100 d-flex justify-content-between align-items-center">
                                <h5 className='d-inline-block'>Founder/ Partner Details</h5>
                                <button className='btn btn-orange-custom'>Add New Founder</button>
                            </div>

                        </div>

                        <div className="col-12 py-5 mt-2 rounded-4 bg-gray-light1">
                            <div className="row">
                                <div className="col-12 col-lg-2">
                                    <div className='w-100 h-100 d-flex flex-column justify-content-top align-items-center'>
                                    <label className="cursor-pointer">
                                        <div className="p-3 rounded-circle developer-profile-details-developer-image position-relative" style={{ backgroundImage: `url(${PlaceholderImage})` }}>
                                        <input type="file" className="d-none" id="input" name="image" accept="image/*" />
                                        <i className="fa fa-pencil-square-o position-absolute text-18 fw-bold" style={{bottom: "10px", right: "10px"}} aria-hidden="true"></i>
                                        </div>
                                        </label>
                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">


                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Name of the Founder/ Partner</label>
                                            <input type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Years in services</label>
                                            <div className="input-group mb-0">
                                                <input type="text" className="form-control input-group-first-input"
                                                    placeholder="00" aria-label="Text input with dropdown button" name='yearinservice' />
                                                <span className="input-group-text" id="basic-addon2">Years</span>
                                            </div>
                                            <p className='text-danger mb-0'></p>
                                        </div>

                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">



                                    <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Qualification</label>
                                            <input type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>

                                    </div>
                                </div>



                            </div>
                        </div>

                        <div className="col-12 py-5 mt-3 rounded-4 bg-gray-light1">
                            <div className="row">
                                <div className="col-12 col-lg-2">
                                    <div className='w-100 h-100 d-flex flex-column justify-content-top align-items-center'>
                                    <label className="cursor-pointer">
                                        <div className="p-3 rounded-circle developer-profile-details-developer-image position-relative" style={{ backgroundImage: `url(${PlaceholderImage})` }}>
                                        <input type="file" className="d-none" id="input" name="image" accept="image/*" />
                                        <i className="fa fa-pencil-square-o position-absolute text-18 fw-bold" style={{bottom: "10px", right: "10px"}} aria-hidden="true"></i>
                                        </div>
                                        </label>
                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">


                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Name of the Founder/ Partner</label>
                                            <input type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Years in services</label>
                                            <div className="input-group mb-0">
                                                <input type="text" className="form-control input-group-first-input"
                                                    placeholder="00" aria-label="Text input with dropdown button" name='yearinservice' />
                                                <span className="input-group-text" id="basic-addon2">Years</span>
                                            </div>
                                            <p className='text-danger mb-0'></p>
                                        </div>

                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">



                                    <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Qualification</label>
                                            <input type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>

                                    </div>
                                </div>



                            </div>
                        </div>

                        <div className="col-12 py-5 mt-3 rounded-4 bg-gray-light1">
                            <div className="row">
                                <div className="col-12 col-lg-2">
                                    <div className='w-100 h-100 d-flex flex-column justify-content-top align-items-center'>
                                    <label className="cursor-pointer">
                                        <div className="p-3 rounded-circle developer-profile-details-developer-image position-relative" style={{ backgroundImage: `url(${PlaceholderImage})` }}>
                                        <input type="file" className="d-none" id="input" name="image" accept="image/*" />
                                        <i className="fa fa-pencil-square-o position-absolute text-18 fw-bold" style={{bottom: "10px", right: "10px"}} aria-hidden="true"></i>
                                        </div>
                                        </label>
                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">


                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Name of the Founder/ Partner</label>
                                            <input type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>
                                        <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Years in services</label>
                                            <div className="input-group mb-0">
                                                <input type="text" className="form-control input-group-first-input"
                                                    placeholder="00" aria-label="Text input with dropdown button" name='yearinservice' />
                                                <span className="input-group-text" id="basic-addon2">Years</span>
                                            </div>
                                            <p className='text-danger mb-0'></p>
                                        </div>

                                    </div>
                                </div>
                                <div className="col-12 col-lg-5">
                                    <div className="row gy-4">



                                    <div className="col-12 col-sm-6 col-lg-12">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Qualification</label>
                                            <input type="text" className="form-control" id="exampleFormControlInput1" maxLength="35" name='EName' />
                                            <p className='text-danger mb-0'></p>
                                        </div>

                                    </div>
                                </div>



                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </Layout>
    )
}

export default DeveloperProfileEdit;