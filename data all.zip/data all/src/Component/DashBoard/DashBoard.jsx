import React, { useEffect } from 'react';
import Header from "../Shared/Header/Header";
import DashboardBnner from "./DashboardBnner/DashboardBnner";
import HelpSection from "./HelpSection/HelpSection";
import Livelife from "./Livelife/Livelife";
import Features from "./Features/Features";
import DashboardVideo from "./DashboardVideo/DashboardVideo";
import ImpactAndGrow from "./ImapctAndGrow/ImpactAndGrow";
import Testimonials from "../DashBoard/Testimonials/Testimonials";
import Faq from "../Shared/Faq/Faq";
import Parners from '../Shared/Partners/Parners';
import Contactus from '../Shared/ContactUs/Contactus';
import Footer from '../Shared/Footer/Footer';
import { useLocation } from "react-router-dom";

const DashBoard = () => {
    const location = useLocation();

    // for the get scroll from another page
    useEffect(() => {
        if (location.pathname === '/feature') {
            window.scrollTo(0, 1800)
        }
        if (location.pathname === '/service') {
            window.scrollTo(0, 600)
        }
    }, [])

    // render from existing page
    useEffect(() => {
        if (location.pathname === '/feature') {
            window.scrollTo(0, 1800)
        }
        if (location.pathname === '/service') {
            window.scrollTo(0, 600)
        }
        if (location.pathname === '/') {
            window.scrollTo(0, 0)
        }
    }, [location])



    return (
        <>
            <div className='home-top-section'>
                <Header />
                <DashboardBnner />
            </div>
            <HelpSection />
            <Livelife />
            <Features />
            <DashboardVideo />
            <ImpactAndGrow />
            <Testimonials />
            <Faq />
            <Parners />
            <Contactus />
            <Footer />
        </>
    )
}

export default DashBoard;