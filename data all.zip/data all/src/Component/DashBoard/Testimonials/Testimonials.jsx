import React from 'react'
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper";
import admin1 from '../../../assets/images/testi-1.jpg'
import admin2 from '../../../assets/images/testi-2.jpg'
import admin3 from '../../../assets/images/testi-3.jpg'

const Testimonials = () => {

    return (
        <div id="testimonials-section" className="testimonials-section container-fluid d-none d-lg-block">
            <div className="container-lg py-4 py-lg-5">
                <h2 className="text-center text-white mb-4 mb-lg-5 fw-bold pt-4">
                    Testimonials
                </h2>
                <div className="swipper-container-custom mb-5">
                    {/* Swiper */}
                    <Swiper
                        
                        slidesPerView={3}
                        navigation={true}
                        modules={[Pagination, Navigation]}
                        className="testimonialsSwiper"
                    >
                        <SwiperSlide>
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={admin1} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">Juan Lee - Product Lead</h5>
                                    <p>
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                        sed do eiusmod tempor incididunt ut labore et dolore magna
                                        aliqua."
                                    </p>
                                </div>
                        </SwiperSlide>
                        <SwiperSlide>
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={admin2} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">Juan Lee - Product Lead</h5>
                                    <p>
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                        sed do eiusmod tempor incididunt ut labore et dolore magna
                                        aliqua."
                                    </p>
                                </div>
                        </SwiperSlide>
                        <SwiperSlide>
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={admin3} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">Juan Lee - Product Lead</h5>
                                    <p>
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                        sed do eiusmod tempor incididunt ut labore et dolore magna
                                        aliqua."
                                    </p>
                                </div>
                        </SwiperSlide>
                        <SwiperSlide>
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={admin1} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">Juan Lee - Product Lead</h5>
                                    <p>
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                        sed do eiusmod tempor incididunt ut labore et dolore magna
                                        aliqua."
                                    </p>
                                </div>
                        </SwiperSlide>
                    </Swiper>
                </div>
            </div>
        </div>
    )
}

export default Testimonials