import React, { useEffect } from 'react'
import Layout from '../Layout/Layout'
import ImageThree from "../../assets/images/blog-img-3.jpg";

const BlogsDetailsThree = () => {

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])


  return (
    <Layout>
       <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                Redevelopment – Partners you need for the process and how to choose them
                </h2>
                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
              <div
                className="p-3 border rounded-20 grow-cards-wrapper" style={{ backgroundImage: `url(${ImageThree})`, backgroundSize: 'cover' }}
              >
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 py-4 pb-0 text-333333">
              <div class="static-wrap">
                <p>Redevelopment of a Property is a lengthy, time-consuming, mentally draining process because of which it is very essential to choose the right Partners to work with you.
                </p>

              </div>

              <div class="static-wrap">
                <p>Let us first take a look at the Partners you require during the whole process:</p>
                <ol class="list-style-decimal">
                  <li><strong>All Owners – </strong>the first and foremost partner in Redevelopment is all the Owners in the Property. Without everyone of them working towards the same goal its impossible to get the Redevelopment right.</li>
                  <li><strong>Architect – </strong>A good Architect who can guide you and advise you on Redevelopment is a boon.  An Architect who works for the Society and not for any Developer is the right Architect since he keeps the Property Owner’s interest in mind rather than Developers. Developers would have their own Architect whose job would be to keep Developer’s interest in mind.</li>
                  <li><strong>Lawyer – </strong>To understand the complex legal framework of RERA, Cooperative Society Act, Contract Act, etc. its essential to appoint a good Lawyer whose job will be to safeguard the interest of Property Owners legally under all circumstances – good or bad. As the saying goes never keep anything away from your Doctor or Lawyer, it’s important to provide all the details to the appointed Lawyer so that he can guide the Property owners properly throughout the process.</li>
                  <li><strong>CA – </strong>Finances, Taxes, Succession, etc. are things that would bother every owner during Redevelopment.  A good Chartered Accountant who is an expert in these fields is a very important partner to be appointed throughout the course of Redevelopment. He would not only be a good advisor to the Property per se but also to all the Owners during the process since they too face difficulties.</li>
                  <li><strong>PMC – </strong>A Project Management Consultant is a person who can combine all the partners mentioned and provide a single window service to the Property Owners. It saves the Property owner’s time to look for each individual partner separately plus you have a single point of contact.</li>
                  <li><strong>Developer – </strong>While many Property Owner’s look at Developers as the enemy or the opposite Party, in Redevelopment factually She is the biggest partner. A good relationship, vibe with Developer is of utmost importance and the biggest factor of all – Trust needs to be built between Developer and Property Owner for a good Redevelopment.</li>
                </ol>
              </div>

              <div class="static-wrap">
                <p>
                  While we learnt about the Partners above, there are four key ingredients to look for in all the partners which are self-explanatory:
                </p>
                <ul class="list-style-disc">
                  <li><strong>Experience – </strong>Atleast 5 to 10 years of experience</li>
                  <li><strong>Quality – </strong>over Price, cost or anything</li>
                  <li><strong>Reputation – </strong>Reference checks would be essential to understand reputation</li>
                  <li><strong>Integrity</strong></li>
                </ul>
              </div>

              <div class="static-wrap">
                <p>Hope this article helps you in getting an idea about the Partners required and how to chose them based on the four essential ingredients. In the next article we will see how to get a Society 100% ready for Redevelopment.  Checkout CA S. Lakshminarayanan’s video series on youtube too for some interesting content on Redevelopment.</p>
                <p>Please contact <a href="tel:+917499553592" target="_blank">7499553592</a> for more info or visit <a href="http://www.dreamsredeveloped.com" target="_blank">www.dreamsredeveloped.com</a> for the same.</p>
              </div>



            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default BlogsDetailsThree