import React, { useEffect } from 'react';
import Layout from '../Layout/Layout';
import ImageFour from "../../assets/images/blog-img-4.jpg";

const BlogsDetailsFour = () => {
    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    return (
        <Layout>
            <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                                Redevelopment - How to get Society ready 100% - PASS
                                </h2>
                                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper" style={{ backgroundImage: `url(${ImageFour})`, backgroundSize: 'cover' }}
                            >
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 py-4 pb-0 text-333333">
                            <div className="static-wrap">
                                <p>We have already seen why to go for redevelopment, who can go for redevelopment, what are the regulations and checklist for Redevelopment and finally the Partners required for Redevelopment previously.
                                </p>

                            </div>

                            <div className="static-wrap">
                                <p>As we discussed in previous article, it is important to get Society 100% ready. Now what are the metrics which enables us to say that we are 100% Pass or ready for Redevelopment.  We have a small acronym for the same called PASS which stands for Paperwork, Area Statement, Same thought process (Consent) and Similar Requirement. Let’s see each of this aspect to understand better:</p>
                                <ol className="list-style-decimal">
                                    <li><strong>P – Paperwork – </strong>We need to be sure about two types of Paperwork in process of Redevelopment. One is Property paperwork which majorly consists of Conveyance, Property Card, Index II, Audits of Society, Elected Representative and Minutes/ Resolution for smooth running of Society.  Second would be individual Flat/ Office/ Commercial space paperwork which majorly consists of Ownership document/ Transfer from will/ gift document, Index II/ Property Card, Loan (if any), Legal disputes (if any), Stamp duty payment on purchase, Search report, etc.  It is quintessential to have these documents clear which will enable a smooth Redevelopment process and also saves time for both Property owner and Developer.</li>
                                    <li><strong>A – Area Statement – </strong>There can be inconsistency in Area statement between what is mentioned in Index II vs what’s there as per Final Sanction plan during construction vs Physical measurement of Flat (if done).  A clean Area statement signed by all Flat owners solves this issue and all Owners would have to come together to get one single measurement approved out of the three mentioned above.  Sometimes, some Owners also claim areas which were not allowed to be sold legally but they have paid for the same previously – in such cases a mutual consent needs to be taken for the benefit of all Members.</li>
                                    <li><strong>S – Same thought process (Consent) – </strong>Like we have previously seen 100% consent is the most beautiful goal to achieve in the process of Redevelopment. According to us (Dreamsredeveloped), a 100% consent society is worth a Diamond amongst properties which don’t have full consent and Developers would love to bid for such plots even if it costs them a part of the profit since it saves something more critical than Money – Time.</li>
                                    <li><strong>S – Similar Requirement – </strong>The last part of the acronym is Similar Requirements which is the requirement list of what each owner’s requirement. While it is understandable that there cannot be same requirement, but similar thought process in this aspect saves a lot of time for Architects and Developers in Designing the new Structure.</li>
                                </ol>
                            </div>

                            <div className="static-wrap">
                                <p>We at Dreamsredeveloped have created an algorithmic score for the same which enables Properties to test their PASS score in an online and transparent way by payment of minimal charges.</p>
                                <p>Please contact <a href="tel:+917499553592" target="_blank">7499553592</a> for more info or visit <a href="http://www.dreamsredeveloped.com" target="_blank">www.dreamsredeveloped.com</a> for the same.</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </Layout>
    )
}

export default BlogsDetailsFour