import React, { useEffect } from 'react';
import Layout from '../Layout/Layout';
import ImageOne from "../../assets/images/blog-img-1.jpg";

const BlogsDetails = () => {

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])


  return (
    <Layout>
      <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                  Redevelopment - Why to go for it, who can go for it and how to go about it
                </h2>
                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
              <div
              className="p-3 border rounded-20 grow-cards-wrapper"  style={{ backgroundImage: `url(${ImageOne})`, backgroundSize: 'cover' }}
              >
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-12 py-4 pb-0 text-333333">
              <div className="static-wrap">
                <p>India had undergone a Real Estate boom in the late 1980s and early 1990s when Residential Buildings (in the form of Society’s or Apartments or Bungalows or Row Houses) were constructed to cater to the needs of the growing middle className and the aspirations of the affluent people. Youngsters with aspirations of staying in a gated society or a standalone building in their enthusiasm and exuberance booked flats which did not have concepts of Lifts/ Parking/ Solar/ etc. then.
                  Cut to the current situation in 2022, those  enthusiastic Couples have turned to their 50s, 60s and 70s and now feel a greater need for Lifts (especially those who stay on the top floor in the 3 storied or 4 storied building), Parking (since 4 wheelers and 2 wheels have become essentials now) and other amenities.  Added to that, due to passage of time the maintenance costs of the old buildings increase not just on the Revenue expenses but also major Capital expenses like Painting, Plumbing, Electrical wiring, etc.  All this combined with their daughters/ sons staying abroad or in another city makes it cumbersome for the once young couple to stay in such high maintenance and low amenities buildings.
                  So, what can be done about this – Continue to stay this way throughout their life or move to a different place with better amenities. What if there is a better solution – Continue to stay in the same building with better amenities by going for Redevelopment.
                  Now – What is Redevelopment? Redevelopment is a combination of two words “Re” and “Development”. As we all know “Development” is developing the building from the ground by building a structure for living or for commercial purpose. “Re” signifies the situation where there is an old buildingwhich is demolished to build a new structure to accommodate the existing owners and adding some more saleable units which can be sold upon completion of construction to make the redevelopment project commercially viable for the Developer.
                </p>
              </div>

              <div className="static-wrap">
                <h3 className="mb-3 fw-bolder">How does Redevelopment work?</h3>
                <h4 className="fw-600 text-16">What is in it for Flat Owners?</h4>
                <p>Existing Flat / Apartment / Bungalow / Row House owners hand over their flats and in lieu of the same get a bigger flat (if the property is in a high potential area) with latest amenities which can include things like Lifts, Parking, Solar, Rainwater Harvesting, Security Systems, Vermiculture, etc. More so during the construction period, their Rentals, Deposits are also taken care of, by the Developer if the potential of the plot is high enough to accommodate these charges.</p>
              </div>

              <div className="static-wrap">
                <h4 className="fw-600 text-16">What is in it for Developers?</h4>
                <p>With land parcels shrinking in the main city areas, Redevelopment is the next viable proposition for Developers. The construction that took place in 1980s and 1990s majorly had a utilization of approx. 1 FSI, but over the period with density of population increasing, the Development Control Regulations have increased the FSI available for a plot in the Cities. The increase in permissible FSI of such areas depend on the size of the plot, width of the road adjoining the plot/ abutting the plot, nearness to Metro (Transit oriented Development or TOD), etc. among the other factors. Additional FSI allows the Developer to construct more flats on the same plot.</p>
                <p>Developers get into an agreement with Societies to demolish the existing construction and construct new building with increased Tenement’s due to the relaxed FSI regulations.  Out of the total tenement’s, Existing flat owners are given their share of Flats (existing area + additional area free of cost) and the remaining flats are sold in the open Market to recoup their construction cost and earn their share of profits.</p>
              </div>

              <div className="static-wrap">
                <h4 className="fw-600 text-16">Why to go for Redevelopment?</h4>
                <p>People who have spent a majority of their lives at one location, tend to have an emotional connect with the place and its surroundings. Redevelopment of the Society allows the existing Residents to enjoy the same surroundings, same friends, same neighbors,   with at a bigger place to live, with new amenities & specifications – what else would one ask for? That is exactly the reason why you should explore Redevelopment.</p>
              </div>

              <div className="static-wrap">
                <h4 className="fw-600 text-16">How to go about Redevelopment?</h4>
                <p>This 12 Article series is going to take you through the factors affecting Redevelopment, process of Redevelopment step by step and also the care that needs to be taken during Redevelopment – so keep watching the space.</p>
                <p>Please contact <a href="tel:+917499553592">7499553592</a> for more info or visit <a href="http://www.dreamsredeveloped.com" target="_blank">www.dreamsredeveloped.com</a> for the same.</p>
              </div>



            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default BlogsDetails