import React, { useEffect } from 'react'
import Layout from '../Layout/Layout'
import Faq from '../Shared/Faq/Faq'
import AdminRoutes from '../../App/Route/RouteDetails';
import { useNavigate } from "react-router-dom";
import ImageOne from "../../assets/images/blog-img-1.jpg";
import ImageTwo from "../../assets/images/blog-img-2.jpg";
import ImageThree from "../../assets/images/blog-img-3.jpg";
import ImageFour from "../../assets/images/blog-img-4.jpg";
import ImageFive from "../../assets/images/blog-img-5.jpg";
import ImageSix from "../../assets/images/blog-img-6.jpg";

const Blogs = () => {
    const navigate = useNavigate();
    const handleBlogsDetails = () => {
        navigate(AdminRoutes.BlogsDetailsOne)
    }

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    return (
        <Layout>
            <div id="grow-section" className="grow-section container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">
                    <div
                        aria-label="breadcrumb"
                        className="mb-4 d-none d-lg-block"
                    >
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <span className="text-black text-decoration-none fw-bold">Home</span>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">
                                <span className="text-purple fw-bold">Blogs</span>
                            </li>
                        </ol>
                    </div>

                    <h2 className="text-left text-purple fw-bold">
                        Go through our informative blogs on Redevelopment.
                    </h2>
                    <hr className="hr-custom-one mb-4 mb-lg-5"></hr>
                    <div className="row g-5">
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer"  style={{ backgroundImage: `url(${ImageOne})`, backgroundSize: 'cover' }} onClick={() => handleBlogsDetails()}>
                                <div className="d-flex flex-column grow-cards m-auto">
                                    <div className="mb-5 mb-lg-2">
                                        <h5 className="fw-bold">Redevelopment - Why to go for it, who can go for it and how to go about it ?</h5>
                                    </div>
                                    <div className="d-flex flex-column justify-content-start">
                                        <span>By CA S Lakshminarayanan</span>
                                        <span>22/02/2022</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer"  style={{ backgroundImage: `url(${ImageTwo})`, backgroundSize: 'cover' }} onClick={() => navigate(AdminRoutes.BlogsDetailsTwo)}>
                                <div className="d-flex flex-column grow-cards m-auto">
                                    <div className="mb-5 mb-lg-2">
                                        <h5 className="fw-bold">Redevelopment Process - Checklist and Relevant Regulations</h5>
                                    </div>
                                    <div className="d-flex flex-column justify-content-start">
                                        <span>By CA S Lakshminarayanan</span>
                                        <span>22/02/2022</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer"  style={{ backgroundImage: `url(${ImageThree})`, backgroundSize: 'cover' }} onClick={() => navigate(AdminRoutes.BlogsDetailsThree)}>
                                <div className="d-flex flex-column grow-cards m-auto">
                                    <div className="mb-5 mb-lg-2">
                                        <h5 className="fw-bold">Redevelopment - Professionals you need for the process and how to choose them</h5>
                                    </div>
                                    <div className="d-flex flex-column justify-content-start">
                                        <span>By CA S Lakshminarayanan</span>
                                        <span>22/02/2022</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer"  style={{ backgroundImage: `url(${ImageFour})`, backgroundSize: 'cover' }} 
                                onClick={() => navigate(AdminRoutes.BlogsDetailsFour)} >
                                <div className="d-flex flex-column grow-cards m-auto">
                                    <div className="mb-5 mb-lg-2">
                                        <h5 className="fw-bold">Redevelopment - How to get Society ready 100% - PASS</h5>
                                    </div>
                                    <div className="d-flex flex-column justify-content-start">
                                        <span>By CA S Lakshminarayanan</span>
                                        <span>22/02/2022</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer"  style={{ backgroundImage: `url(${ImageFive})`, backgroundSize: 'cover' }} 
                                onClick={() => navigate(AdminRoutes.BlogsDetailsFive)}>
                                <div className="d-flex flex-column grow-cards m-auto">
                                    <div className="mb-5 mb-lg-2">
                                        <h5 className="fw-bold">Redevelopment - Feasibility Report - types of Reports Advantages and Disadvantages</h5>
                                    </div>
                                    <div className="d-flex flex-column justify-content-start">
                                        <span>By CA S Lakshminarayanan</span>
                                        <span>22/02/2022</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer"  style={{ backgroundImage: `url(${ImageSix})`, backgroundSize: 'cover' }} 
                                onClick={() => navigate(AdminRoutes.BlogsDetailsSix)}>
                                <div className="d-flex flex-column grow-cards m-auto">
                                    <div className="mb-5 mb-lg-2">
                                        <h5 className="fw-bold">Redevelopment - What matters more - % or Amenities or Balanced Expectations</h5>
                                    </div>
                                    <div className="d-flex flex-column justify-content-start">
                                        <span>By CA S Lakshminarayanan</span>
                                        <span>22/02/2022</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Faq />
        </Layout>
    )
}

export default Blogs